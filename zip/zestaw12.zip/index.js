const change_to_indigo = () => {
    document.getElementById('right').style.backgroundColor = "indigo";
}

const change_to_steelblue = () => {
    document.getElementById('right').style.backgroundColor = "steelblue";
}

const change_to_olive = () => {
    document.getElementById('right').style.backgroundColor = "olive";
}

const change_font_color = () => {
    let x = document.getElementById('list').value;
    document.getElementById('right').style.color = x;
}

const change_size = () => {
    let x = document.getElementById('czcionka').value;
    document.getElementById('right').style.fontSize = x;
}

const change_border = () => {
    if (document.getElementById('box').checked) {
        document.getElementById('img').style.border = '1px solid white';
    }
    else {
        document.getElementById('img').style.border = 'none';
    }
}

const radio = (rad) => {
    let radiopalette = document.getElementById('lista2');
    if (rad == 'dysk') {
        radiopalette.style.listStyle = 'disc';
    }
    if (rad == 'kwadrat') {
        radiopalette.style.listStyle = 'square';
    }
    if (rad == 'okrąg') {
        radiopalette.style.listStyle = 'circle';
    }

}




// Jan Kupczyk