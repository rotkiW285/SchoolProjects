<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo - Szczegóły produktu</title>
    <meta property="og:title" content="Alledrogo - Szczegóły produktu">
    <link rel="stylesheet" href="css/more-info.css">
    <?php include 'navbar.php'; ?>
    <main>
        <?php
        include 'db_conn.php';
        if (isset($_GET['id'])) {
            $product_id = $_GET['id'];

            if (is_numeric($product_id)) {
                $product_id = intval($product_id);
                $sql = "SELECT products.*, categories.name as category_name FROM products 
                        LEFT JOIN categories ON products.category_id = categories.category_id 
                        WHERE products.product_id = $product_id";

                $result = mysqli_query($conn, $sql);

                if ($result && mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_assoc($result);

                    echo '<div class="product-details">';
                    echo '<div class="product-image">';
                    echo '<img src="assets/products/' . htmlspecialchars($row["image_url"]) . '" alt="' . htmlspecialchars($row["name"]) . '">';
                    echo '</div>';

                    echo '<div class="product-info">';
                    echo '<h1>' . htmlspecialchars($row["name"]) . '</h1>';

                    if (!empty($row["category_name"])) {
                        echo '<div class="category">Kategoria: ' . htmlspecialchars($row["category_name"]) . '</div>';
                    }

                    echo '<div class="price">' . number_format($row["price"], 2) . ' zł</div>';

                    echo '<div class="stock">Status: ' . htmlspecialchars($row["status"]) . '</div>';

                    $seller_id = $row["seller_id"];
                    $seller_query = "SELECT username FROM users WHERE user_id = $seller_id";
                    $seller_result = mysqli_query($conn, $seller_query);
                    
                    if ($seller_result && mysqli_num_rows($seller_result) > 0) {
                        $seller_row = mysqli_fetch_assoc($seller_result);
                        echo '<i class="seller">Sprzedający: ' . htmlspecialchars($seller_row["username"]) . '</i>';
                    } else {
                        echo '<i class="seller">Sprzedający: Nieznany</i>';
                    }

                    echo '<div class="description">' . nl2br(htmlspecialchars($row["description"])) . '</div>';
                    echo '<a class="contact-seller-btn" href="contact-seller?id=' . $row["product_id"] . '">Skontaktuj się z sprzedającym</a><br><br>';
                    echo '<button type="button" onclick="addToCart(\'' . $row["product_id"] . '\'); return false;" class="add-to-cart">Dodaj do koszyka</button>';
                    echo '</div>';
                    echo '</div>';
                } else {
                    echo "<h2>Nie znaleziono produktu.</h2>";
                }
            } else {
                echo "<h2>Nieprawidłowy identyfikator produktu (musisz podać liczbę).</h2>";
            }
        } else {
            echo "<h2>Nie znaleziono parametru 'id' w URL.</h2>";
        }
        mysqli_close($conn);
        ?>
    </main>
    <script src="js/cart.js"></script>
    <?php include 'footer.php'; ?>