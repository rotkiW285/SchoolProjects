<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: account");
    exit();
}

$message = '';
$error = '';

function pobranie($query, $params = [])
{
    require 'db_conn.php';

    $result = mysqli_query($conn, $query);
    if (!$result) {
        return false;
    }

    $dane = mysqli_fetch_assoc($result);
    mysqli_close($conn);
    return $dane;
}

function zapytanie($query, $params = [])
{
    require 'db_conn.php';

    $result = mysqli_query($conn, $query);
    $sukces = ($result !== false);
    mysqli_close($conn);
    return $sukces;
}

if (isset($_POST['change_password'])) {
    $user_id = $_SESSION['id'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $error = "Nowe hasła nie są identyczne.";
    } else {
        $query = "SELECT password FROM users WHERE user_id = " . $user_id;
        $user_data = pobranie($query);

        if ($user_data && password_verify($current_password, $user_data['password'])) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_query = "UPDATE users SET password = '$hashed_password' WHERE user_id = $user_id";

            if (zapytanie($update_query)) {
                $message = "Hasło zostało zmienione pomyślnie.";
            } else {
                $error = "Wystąpił błąd podczas zmiany hasła.";
            }
        } else {
            $error = "Obecne hasło jest nieprawidłowe.";
        }
    }
}

if (isset($_POST['delete_account'])) {
    $user_id = $_SESSION['id'];
    $password = $_POST['delete_password'];

    $query = "SELECT password FROM users WHERE user_id = " . $user_id;
    $user_data = pobranie($query);

    if ($user_data && password_verify($password, $user_data['password'])) {
        $update_products_query = "UPDATE products SET status = 'Nieaktywne' WHERE seller_id = $user_id";
        zapytanie($update_products_query);

        $delete_query = "DELETE FROM users WHERE user_id = $user_id";
        if (zapytanie($delete_query)) {
            session_destroy();
            header("Location: /?success=Konto zostało usunięte. Dziękujemy za korzystanie z naszego serwisu.");
            exit();
        } else {
            $error = "Wystąpił błąd podczas usuwania konta.";
        }
    } else {
        $error = "Podane hasło jest nieprawidłowe.";
    }
}
?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <title>Alledrogo - Zarządzanie kontem</title>
    <meta property="og:title" content="Alledrogo - Zarządzanie kontem">
    <link rel="stylesheet" href="css/acc-managment.css">
    <?php include 'navbar.php'; ?>

    <main>
        <?php if (!empty($message)): ?>
            <div class="success-message"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        <div class="form-wrapper">
            <a href="account-info" id="submit">Powrót do informacji o koncie</a>
            <h1>Zarządzanie kontem</h1>

            <div class="management-options">
                <div class="account-section">
                    <h3>Zmiana hasła</h3>
                    <form id="change-password-form" method="post" onsubmit="return validatePasswordChange()">
                        <div class="form-group">
                            <label for="current_password">Obecne hasło:</label>
                            <input type="password" id="current_password" name="current_password" required>
                        </div>

                        <div class="form-group">
                            <label for="new_password">Nowe hasło:</label>
                            <input type="password" id="new_password" name="new_password" required><br>
                            <small>Hasło powinno zawierać od 8 do 60 znaków, w tym przynajmniej jedną dużą literę i cyfrę.</small>
                        </div>

                        <div class="form-group">
                            <label for="confirm_password">Powtórz nowe hasło:</label>
                            <input type="password" id="confirm_password" name="confirm_password" required>
                        </div>

                        <div id="password-error" class="error-text"></div>

                        <button type="submit" name="change_password" id="submit">Zmień hasło</button>
                    </form>
                </div>

                <div class="account-section" style="border: 2px solid #f44336;">
                    <h3>Usunięcie konta</h3>
                    <p class="warning-text">Uwaga! Usunięcie konta jest nieodwracalne. Wszystkie Twoje dane zostaną
                        bezpowrotnie usunięte.</p>

                    <button id="show-delete-form" class="btn-danger">Usuń konto</button>

                    <div id="delete-account-form" style="display: none;">
                        <form method="post" onsubmit="return confirmAccountDeletion()">
                            <div class="form-group">
                                <label for="delete_password">Podaj hasło, aby potwierdzić:</label>
                                <input type="password" id="delete_password" name="delete_password" required>
                            </div>

                            <button type="submit" name="delete_account" class="btn-danger">Potwierdzam usunięcie konta</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="js/validate-password.js"></script>
    <script>
        document.getElementById('show-delete-form').addEventListener('click', function() {
            var form = document.getElementById('delete-account-form');
            if (form.style.display === 'none') {
                form.style.display = 'block';
                this.textContent = 'Anuluj';
            } else {
                form.style.display = 'none';
                this.textContent = 'Usuń konto';
            }
        });

        function validatePasswordChange() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const errorElement = document.getElementById('password-error');

            if (newPassword !== confirmPassword) {
                errorElement.textContent = 'Hasła nie są identyczne.';
                return false;
            }

            const isValid = validatePassword(newPassword);
            if (!isValid) {
                const errorMessage = getPasswordErrorMessage(newPassword);
                errorElement.textContent = errorMessage || 'Hasło nie spełnia wymagań bezpieczeństwa.';
                return false;
            }

            return true;
        }

        function confirmAccountDeletion() {
            return confirm('Czy na pewno chcesz usunąć swoje konto? Ta operacja jest nieodwracalna.');
        }
    </script>
    <?php include 'footer.php'; ?>