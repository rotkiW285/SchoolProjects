<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo - Koszyk</title>
    <link rel="stylesheet" href="css/cart.css">
    <meta property="og:title" content="Alledrogo - Koszyk" />
    <?php include 'navbar.php'; ?>
    <main>
        <div class="cart-container" id="cart-container">
            <h1>Koszyk</h1>
            <div class="loading">Ładowanie zawartości koszyka...</div>
            <div class="cart-summary" id="cart-summary" style="display: none;">
                <div class="summary-row">
                    <span>Suma:</span>
                    <span id="cart-total">0.00 zł</span>
                </div>
                <button id="checkout-button" class="checkout-button">Przejdź do płatności</button>
            </div>
            <div id="empty-cart-message" style="display: none;">
                Twój koszyk jest pusty.
            </div>
        </div>
    </main>
    <script src="js/cart.js"></script>
    <?php include 'footer.php'; ?>