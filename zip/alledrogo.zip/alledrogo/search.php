<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo - Wyszukiwarka</title>
    <meta property="og:title" content="Alledrogo - Wyszukiwarka" />
    <link rel="stylesheet" href="css/category.css">
    <?php include 'navbar.php'; ?>
    <main>
        <div class="category-list">
            <?php
            if (isset($_GET['query']) && !empty($_GET['query'])) {
                $query = htmlspecialchars($_GET['query']);

                include 'db_conn.php';

                $searchTerm = "%" . $query . "%";
                $sql = "SELECT product_id, name, price, description, image_url, status, seller_id FROM products WHERE name LIKE '$searchTerm' OR description LIKE '$searchTerm'";
                $result = mysqli_query($conn, $sql);

                echo "<h1>Wyniki wyszukiwania dla: " . $query . "</h1>";

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<div class="product-category">';
                        echo '<div class="category-img"><img src="assets/products/' . $row["image_url"] . '" alt="Produkt"></div>';
                        echo '<div class="category-info">';
                        echo '<h2>' . $row["name"] . '</h2>';
                        echo '<div id="price">' . number_format($row["price"], 2, ',', ' ') . ' zł</div>';
                        echo "Status: " . $row["status"];

                        $seller_id = $row["seller_id"];
                        $seller_query = "SELECT username FROM users WHERE user_id = $seller_id";
                        $seller_result = mysqli_query($conn, $seller_query);

                        if ($seller_result && mysqli_num_rows($seller_result) > 0) {
                            $seller_row = mysqli_fetch_assoc($seller_result);
                            echo '<i class="seller">Sprzedający: ' . htmlspecialchars($seller_row["username"]) . '</i>';
                        } else {
                            echo '<i class="seller">Sprzedający: Nieznany</i>';
                        }

                        echo '<p id="description">' . $row["description"] . '</p>';
                        echo '<div class="product-button"> <a href="more-info?id=' . $row["product_id"] . '" class="more-info-btn"> Więcej informacji</a></div>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo "<p class='message-error'>Nie znaleziono produktów pasujących do zapytania<br>Spróbuj użyć innych słów kluczowych lub sprawdź pisownię.</p>";
                }
                echo "</div>";

                mysqli_close($conn);
            } else {
                echo "<h1>Wyszukiwarka</h1>";
                echo "<p>Wprowadź szukaną frazę w pasku wyszukiwania.</p>";
            }
            ?>
        </div>
    </main>
    <?php include 'footer.php'; ?>