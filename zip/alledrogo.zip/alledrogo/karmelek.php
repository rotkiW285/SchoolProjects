<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Karmelek - Alledrogo</title>
    <meta property="og:title" content="Karmelek - Alledrogo">
    <style>
        #image-container img {
            max-width: 100%;
            border-radius: 8px;
            grid-row: 1 / -1;
            grid-column: 1;
            margin: 0;
            display: grid;
            grid-template-rows: 1fr auto;
            margin-bottom: 10px;
            break-inside: avoid;
        }

        #image-container {
            column-count: 1;
            column-gap: 10px;
        }

        @media screen and (min-width: 720px) {
            #image-container {
                column-count: 2;
            }
        }

        @media screen and (min-width: 1024px) {
            #image-container {
                column-count: 3;
            }
        }

        @media screen and (min-width: 1440px) {
            #image-container {
                column-count: 4;
            }
        }
    </style>

    <?php include 'navbar.php'; ?>

    <main>
        <div id="image-container"></div>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            fetch('https://karmelekapi.mily.ovh/')
                .then(response => response.json())
                .then(data => {
                    const imageContainer = document.getElementById('image-container');
                    data.images.forEach(imageUrl => {
                        const img = document.createElement('img');
                        img.src = imageUrl;
                        img.alt = 'Karmelek';
                        imageContainer.appendChild(img);
                    });
                })
                .catch(error => console.error('Błąd pobierania obrazów:', error));
        });
    </script>
    <?php include 'footer.php'; ?>