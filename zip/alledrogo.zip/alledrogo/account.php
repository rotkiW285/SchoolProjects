<?php
session_start();

if (isset($_SESSION['id'])) {
    header("Location: account-info");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo - Konto</title>
    <meta property="og:title" content="Alledrogo - Konto">
    <link rel="stylesheet" href="css/register.css">
    <?php include 'navbar.php'; ?>

    <main>
        <form action="account.php" method="post" id="loginForm">
            <?php
            if (isset($_GET['error'])) {
                echo '<div class="message-error">' . htmlspecialchars($_GET['error']) . '</div>';
            }
            
            if (isset($_GET['success'])) {
                echo '<div class="message-success">' . htmlspecialchars($_GET['success']) . '</div>';
            }
            ?>

            <div class="register-container">
                <h2>LOGOWANIE</h2>

                <label>Nazwa użytkownika</label>
                <input type="text" name="username" id="username" placeholder="Nazwa użytkownika" required><br>

                <label>Hasło</label>
                <input type="password" name="password" id="password" placeholder="Hasło" required><br>
                <p id="passwordError" style="color: red; display: none;"></p>

                <button type="submit" id="submit">Zaloguj się</button>
            </form>
            <h3>Nie masz konta? | <a href="register">Zarejestruj się!</a></h3>
        </div>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            include 'db_conn.php';
            
            $username = $_POST['username'];
            $username = mysqli_real_escape_string($conn, $username);
            $password = $_POST['password'];
            
            if (empty($username)) {
                header("Location: account?error=Nazwa użytkownika jest wymagana");
                exit();
            } else if (empty($password)) {
                header("Location: account?error=Hasło jest wymagane");
                exit();
            } else {
                $sql = "SELECT * FROM users WHERE username='$username'";
                $result = mysqli_query($conn, $sql);
                
                if (mysqli_num_rows($result) === 1) {
                    $row = mysqli_fetch_assoc($result);
                    
                    if (password_verify($password, $row['password'])) {
                        $_SESSION['id'] = $row['user_id'];
                        $_SESSION['first_name'] = $row['first_name'];
                        $_SESSION['is_admin'] = $row['is_admin'];
                        
                        header("Location: account-info");
                        exit();
                    } else {
                        header("Location: account?error=Nieprawidłowa nazwa użytkownika lub hasło");
                        exit();
                    }
                } else {
                    header("Location: account?error=Nieprawidłowa nazwa użytkownika lub hasło");
                    exit();
                }
            }
        }
        ?>
    </main>
    <?php include 'footer.php'; ?>