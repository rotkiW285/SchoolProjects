<?php session_start(); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css">
<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
<link rel="manifest" href="favicon/site.webmanifest">
<meta name="theme-color" content="#333" />
<meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
<meta name="description" content="Zawsze może być drożej">
<meta property="og:description" content="Zawsze może być drożej">
<meta property="og:image" content="https://alledrogo.285.ovh/assets/embed.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:url" content="https://alledrogo.285.ovh">
<meta property="og:type" content="website">
</head>
<body>
    <nav>
        <div class="logo">
            <img src="assets/logo.svg" alt="Alledrogo logo">
            <p id="time"></p>
        </div>
        <div class="search">
            <form action="search" method="GET">
                <input type="text" name="query" placeholder="Czego szukasz?" required>
                <button type="submit">Szukaj</button>
            </form>
        </div>
        <div class="buttons">
            <?php
            if (isset($_SESSION['id'])) {
                echo '<a href="add-product"><ion-icon name="add-outline"></ion-icon></a>';
                echo '<a href="cart"><ion-icon name="cart-outline"></ion-icon></a>';
                echo '<a href="messages"><ion-icon name="chatbox-outline"></ion-icon></a>';
            }
            ?>
            <a href="account" style="margin-left: 8px;">
                <?php
                if (isset($_SESSION['first_name'])) {
                    echo "Witaj " . $_SESSION['first_name'] . "!<br>Moje Alledrogo";
                } else {
                    echo "Moje Alledrogo";
                }
                ?>
            </a>
            <?php
            if (isset($_SESSION['id'])) {
                echo '<a href="logout"><ion-icon name="log-in-outline"></ion-icon></a>';
            }
            ?>
        </div>
    </nav>
    <?php
    include 'db_conn.php';

    $sql = "SELECT category_id, name FROM categories";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo '<div class="categories">';
        echo '<a href="/">Strona główna</a>';
        while ($row = $result->fetch_assoc()) {
            echo '<a href="kategoria?id=' . $row["category_id"] . '">' . $row["name"] . '</a>';
        }
        echo '</div>';
    } else {
        echo "Nie znaleziono kategorii";
    }

    mysqli_close($conn);
    ?>
    <script src="js/time.js"></script>
    <script type="module" src="https://cdn.jsdelivr.net/npm/ionicons@latest/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://cdn.jsdelivr.net/npm/ionicons@latest/dist/ionicons/ionicons.js"></script>