<?php  

$host = "db.dom285.pl";
$uname = "user";
$password = "";
$db_name = "alledrogo";

$conn  = mysqli_connect($host, $uname, $password, $db_name);

if (!$conn) {
 echo "Connection failed!";
}

// error_reporting(E_ALL);
// ini_set('display_errors', 1);