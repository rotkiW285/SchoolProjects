<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo</title>
    <meta property="og:title" content="Alledrogo">
    <?php include 'navbar.php';
    if (isset($_GET['error'])): ?>
            <div class="message-error"><?php echo $_GET['error']; ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['success'])): ?>
            <div class="message-success"><?php echo $_GET['success']; ?></div>
        <?php endif; ?>
    <header>
        <video src="assets/animation.mp4" autoplay mute loop></video>
    </header>
    <main>
        <h2 id="sponsored">Sponsorowane <button onclick="showAlert()"><ion-icon name="information-circle-outline"
                    style="font-size: 23px;"></ion-icon></button></h2>
        <div class="products">
            <?php
            include 'db_conn.php';
            
            $zapytanie = "SELECT * FROM products WHERE is_sponsored = 1 AND status = 'Aktywne'";
            $wynik = mysqli_query($conn, $zapytanie);
            
            if (mysqli_num_rows($wynik) > 0) {
                while ($produkt = mysqli_fetch_array($wynik)) {
                    $nazwa = $produkt["name"];
                    $cena = $produkt["price"];
                    $obrazek = $produkt["image_url"];
                    $id = $produkt["product_id"];
                    
                    echo "<div class='product'>";
                    echo "<img src='assets/products/$obrazek' alt='Produkt'><br>";
                    echo "<div class='product-info'>";
                    echo "<p>$nazwa</p>";
                    echo "</div>";
                    echo "<div id='price'>$cena zł</div>";
                    echo "<div><a href='more-info?id=$id' class='more-info-btn'> Więcej informacji</a></div>";
                    echo "</div>";
                }
            } else {
                echo "Brak sponsorowanych produktów";
            }
            
            mysqli_close($conn);
            ?>
        </div>
    </main>
    <script>
        function showAlert() {
            alert('Oferty sponsorowane są pozycjonowane na górze listy ofert. Dzięki temu Twoja oferta będzie widoczna dla większej liczby użytkowników. Aby zamówić ofertę sponsorowaną, skontaktuj się z nami!');
        }
    </script>
    <?php include 'footer.php'; ?>