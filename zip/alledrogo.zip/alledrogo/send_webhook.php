<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '';
    $email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '';
    $subject = isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : '';
    $message = isset($_POST['message']) ? htmlspecialchars($_POST['message']) : '';
    
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        header("Location: contact?error=Wszystkie pola muszą być wypełnione");
        exit();
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: contact?error=Nieprawidłowy adres email");
        exit();
    }
    
    $webhookUrl = "https://discord.com/api/webhooks/1353124769360380084/O_8rRURI_8vVu5G-Z5hlM12I0WvBOGiWAPJ45FHFP_FWb92ano6yg7PntfvV1f9lpASZ";
    
    $timestamp = date("c", strtotime("now"));
    
    $json_data = json_encode([
        "embeds" => [
            [
                "title" => "Temat: $subject",
                "type" => "rich",
                "description" => $message,
                "color" => hexdec("52b3dd"),
                "timestamp" => $timestamp,
                "footer" => [
                    "text" => "Alledrogo - Formularz kontaktowy"
                ],
                "fields" => [
                    [
                        "name" => "Od",
                        "value" => "$name",
                        "inline" => true
                    ],
                    [
                        "name" => "Email",
                        "value" => "$email",
                        "inline" => true
                    ]
                ]
            ]
        ]
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    
    $ch = curl_init($webhookUrl);
    
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpcode >= 200 && $httpcode < 300) {
        header("Location: contact?success=Wiadomość została wysłana. Dziękujemy za kontakt!");
    } else {
        header("Location: contact?error=Wystąpił błąd podczas wysyłania wiadomości.");
    }
    exit();
} else {
    header("Location: contact");
    exit();
}