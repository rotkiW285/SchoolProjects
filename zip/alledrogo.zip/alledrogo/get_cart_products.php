<?php
include 'db_conn.php';

if (isset($_GET['ids'])) {
    $ids = explode(',', $_GET['ids']);
    $safeIds = array_map(function ($id) use ($conn) {
        return (int) $id;
    }, $ids);

    $safeIds = array_filter(array_unique($safeIds));

    if (empty($safeIds)) {
        echo json_encode([]);
        exit;
    }

    $idString = implode(',', $safeIds);
    $sql = "SELECT product_id, name, description, price, image_url FROM products WHERE product_id IN ($idString)";
    $result = $conn->query($sql);

    $products = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
    }

    header('Content-Type: application/json');
    echo json_encode($products);
} else {
    echo json_encode([]);
}
?>