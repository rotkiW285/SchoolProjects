<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Kontakt - Alledrogo</title>
    <meta property="og:title" content="Kontakt - Alledrogo">
    <link rel="stylesheet" href="css/register.css">
    <?php include 'navbar.php';

    $userName = '';
    $userEmail = '';

    if (isset($_SESSION['id'])) {
        include 'db_conn.php';
        $user_id = $_SESSION['id'];

        $query = "SELECT first_name, last_name, email FROM users WHERE user_id = $user_id";
        $result = mysqli_query($conn, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            $userName = $user['first_name'] . ' ' . $user['last_name'];
            $userEmail = $user['email'];
        }

        mysqli_close($conn);
    }
    ?>

    <?php if (isset($_GET['error'])): ?>
        <div class="message-error"><?php echo $_GET['error']; ?></div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
        <div class="message-success"><?php echo $_GET['success']; ?></div>
    <?php endif; ?>

    <main>
        <div class="register-container">
            <h2>Formularz kontaktowy</h2>
            <form class="form" action="send_webhook.php" method="POST">

                <div class='form-group' <?php echo isset($_SESSION['id']) ? 'style="display: none;"' : ''; ?>>
                    <label for='name'>Imię i nazwisko:</label>
                    <input type='text' id='name' name='name' value='<?php echo htmlspecialchars($userName); ?>' required>

                    <label for="email">Adres e-mail:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($userEmail); ?>" required>
                </div>

                <div class="form-group">
                    <label for="subject">Temat:</label>
                    <input type="text" id="subject" name="subject" required>

                    <label for="message">Wiadomość:</label>
                    <textarea id="message" name="message" required></textarea>
                </div>

                <button id="submit" type="submit">Wyślij wiadomość</button>
            </form>
        </div>
    </main>

    <?php include 'footer.php'; ?>

</html>