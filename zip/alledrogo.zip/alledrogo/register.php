<?php
include 'db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];

    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);

    if (empty($username)) {
        $errors[] = "Nazwa użytkownika jest wymagana";
    } elseif (!preg_match("/^[a-zA-Z0-9_-]+$/", $username)) {
        $errors[] = "Nazwa użytkownika może zawierać tylko litery, cyfry, myślnik (-) i podkreślenie (_). ";
    }

    if (empty($email)) {
        $errors[] = "Email jest wymagany";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Podaj prawidłowy adres email";
    } else {
        $email_check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
        if (mysqli_num_rows($email_check) > 0) {
            $errors[] = "Użytkownik o podanym emailu już istnieje";
        }
    }

    $username_check = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    if (mysqli_num_rows($username_check) > 0) {
        $errors[] = "Użytkownik o podanej nazwie już istnieje";
    }

    if (empty($password)) {
        $errors[] = "Hasło jest wymagane";
    } elseif (strlen($password) < 8) {
        $errors[] = "Hasło musi mieć min. 8 znaków";
    } elseif (strlen($password) > 60) {
        $errors[] = "Hasło nie może mieć więcej niż 60 znaków.";
    } elseif (!preg_match('/\d/', $password)) {
        $errors[] = "Hasło musi zawierać co najmniej jedną cyfrę.";
    } elseif ($password !== $confirm_password) {
        $errors[] = "Hasła nie pasują do siebie.";
    } elseif (!preg_match('/[A-Z]/', $password)) {
        $errors[] = "Hasło musi zawierać co najmniej jedną dużą literę.";
    }

    if (!isset($_POST['terms'])) {
        $errors[] = "Akceptacja regulaminu jest wymagana.";
    }

    if (!empty($errors)) {
        header("Location: register?error=" . urlencode(implode(". ", $errors)));
        exit();
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, email, password, first_name, last_name) 
            VALUES ('$username', '$email', '$hashed_password', '$first_name', '$last_name')";

    if (mysqli_query($conn, $sql)) {
        header("Location: account?success=Rejestracja zakończona sukcesem");
        exit();
    } else {
        header("Location: register?error=Błąd podczas rejestracji, spróbuj ponownie");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <title>Alledrogo - Rejestracja</title>
    <meta property="og:title" content="Alledrogo - Rejestracja">
    <link rel="stylesheet" href="css/register.css">
    <?php include 'navbar.php'; ?>

    <main>
        <?php if (isset($_GET['error'])): ?>
            <div class="message-error"><?php echo $_GET['error']; ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['success'])): ?>
            <div class="message-success"><?php echo $_GET['success']; ?></div>
        <?php endif; ?>

        <form action="register.php" method="POST" onsubmit="return validateForm()">
            <div class="register-container">
                <h2>REJESTRACJA</h2>
                <input type="text" name="first_name" placeholder="Imię" required maxlength="50"><br>
                <input type="text" name="last_name" placeholder="Nazwisko" required maxlength="50"><br>
                <input type="text" name="username" placeholder="Nazwa użytkownika" required maxlength="50"><br>

                <input type="email" name="email" placeholder="E-mail" required maxlength="100"><br>

                <input type="password" name="password" id="password" placeholder="Hasło" maxlength="60" required>
                <input type="password" name="confirm_password" id="confirm_password" placeholder="Potwierdź hasło" required>
                <small>Hasło powinno zawierać od 8 do 60 znaków, w tym przynajmniej jedną dużą literę i cyfrę.</small><br>
                <p id="password-error"></p>

                <div class="checkbox-container">
                    <input type="checkbox" name="terms" id="terms" required>
                    <label for="terms">Akceptuję <a href="regulamin" target="_blank" style="text-decoration: underline">regulamin</a> (wymagane)</label>
                </div>
                <div id="terms-error" class="register-error-message"></div>

                <button type="submit" id="submit">Zarejestruj się</button><br>

        </form>
        <h3>Masz konto? | <a href="account">Zaloguj się</a></h3>
        </div>

        <?php include 'footer.php'; ?>
        <script src="js/validate-password.js"></script>