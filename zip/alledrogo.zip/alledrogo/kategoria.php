<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo - Kategorie</title>
    <meta property="og:title" content="Alledrogo - Kategorie" />
    <link rel="stylesheet" href="css/category.css">
    <?php include 'navbar.php'; ?>
    <main>
        <div class="category-list">
            <?php
            include 'db_conn.php';

            if (isset($_GET['id'])) {
                $category_id = $_GET['id'];

                if (is_numeric($category_id)) {
                    $result = mysqli_query($conn, "SELECT * FROM products WHERE category_id = $category_id AND status = 'Aktywne'");

                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo '<div class="product-category">';
                            echo '<div class="category-img"><img src="assets/products/' . $row["image_url"] . '" alt="Produkt"></div>';
                            echo '<div class="category-info">';
                            echo '<h2>' . $row["name"] . '</h2>';
                            echo '<div id="price">' . $row["price"] . ' zł</div>';
                            echo "Status: " . $row["status"];

                            $seller_id = $row["seller_id"];
                            $seller_query = "SELECT username FROM users WHERE user_id = $seller_id";
                            $seller_result = mysqli_query($conn, $seller_query);

                            if ($seller_result && mysqli_num_rows($seller_result) > 0) {
                                $seller_row = mysqli_fetch_assoc($seller_result);
                                echo '<i class="seller">Sprzedający: ' . htmlspecialchars($seller_row["username"]) . '</i>';
                            } else {
                                echo '<i class="seller">Sprzedający: Nieznany</i>';
                            }

                            echo '<p id="description">' . $row["description"] . '</p>';
                            echo '<div class="product-button"> <a href="more-info?id=' . $row["product_id"] . '" class="more-info-btn"> Więcej informacji</a></div>';
                            echo '</div>';
                            echo '</div>';
                        }
                    } else {
                        echo "<h2>Brak produktów w tej kategorii.</h2>";
                    }
                } else {
                    echo "<h2>Nieprawidłowy identyfikator kategorii (musisz podać liczbę).</h2>";
                }
            } else {
                echo "<h2>Nie znaleziono parametru 'id' w URL.</h2>";
            }

            mysqli_close($conn);
            ?>
        </div>
    </main>
    <?php include 'footer.php'; ?>