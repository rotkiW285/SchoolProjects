<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo - Regulamin</title>
    <meta property="og:title" content="Alledrogo - Regulamin">
    <link rel="stylesheet" href="css/regulamin.css">
    <?php include 'navbar.php'; ?>

    <main>
        <div class="regulamin-container">
            <h1>Regulamin serwisu Alledrogo</h1>
            <p class="update">Data ostatniej aktualizacji: 10.03.2025</p>

            <div class="section">
                <h2>§1. Postanowienia ogólne</h2>
                <ol>
                    <li>Niniejszy Regulamin określa zasady korzystania z serwisu internetowego Alledrogo, dostępnego pod
                        adresem alledrogo.285.ovh.</li>
                    <li>Operatorem Serwisu jest firma Alledrogo S.A. z siedzibą w Warszawie, ul. Fikcyjna 123, 00-001
                        Warszawa, wpisana do rejestru przedsiębiorców prowadzonego przez Sąd Rejonowy dla m.st.
                        Warszawy, XII Wydział Gospodarczy Krajowego Rejestru Sądowego pod numerem KRS 0000000000, NIP
                        0000000000, REGON 000000000.</li>
                    <li>Regulamin jest udostępniony Użytkownikom nieodpłatnie za pośrednictwem Serwisu w formie
                        umożliwiającej jego pobranie, utrwalenie i wydrukowanie.</li>
                    <li>Warunkiem korzystania z Serwisu jest zapoznanie się z treścią Regulaminu i jego akceptacja.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§2. Definicje</h2>
                <ol>
                    <li><strong>Serwis</strong> - serwis internetowy Alledrogo dostępny pod adresem alledrogo.285.ovh;
                    </li>
                    <li><strong>Użytkownik</strong> - osoba fizyczna, osoba prawna lub jednostka organizacyjna
                        nieposiadająca osobowości prawnej, która korzysta z usług Serwisu;</li>
                    <li><strong>Konto</strong> - zbiór zasobów w systemie teleinformatycznym Operatora, w którym
                        gromadzone są dane Użytkownika;</li>
                    <li><strong>Sprzedający</strong> - Użytkownik, który za pośrednictwem Serwisu oferuje zbycie rzeczy;
                    </li>
                    <li><strong>Kupujący</strong> - Użytkownik, który nabywa rzecz od Sprzedającego za pośrednictwem
                        Serwisu;</li>
                    <li><strong>Transakcja</strong> - umowa sprzedaży zawierana za pośrednictwem Serwisu między
                        Kupującym a Sprzedającym.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§3. Warunki techniczne korzystania z Serwisu</h2>
                <ol>
                    <li>W celu prawidłowego korzystania z Serwisu wymagane jest:
                        <ul>
                            <li>urządzenie z dostępem do internetu;</li>
                            <li>przeglądarka internetowa obsługująca JavaScript i pliki cookies;</li>
                            <li>aktywne konto e-mail;</li>
                            <li>włączona obsługa JavaScript w przeglądarce.</li>
                        </ul>
                    </li>
                    <li>Operator nie ponosi odpowiedzialności za problemy techniczne bądź ograniczenia techniczne
                        występujące w urządzeniu, z którego korzysta Użytkownik, a które uniemożliwiają lub ograniczają
                        Użytkownikowi korzystanie z Serwisu.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§4. Rejestracja i konto Użytkownika</h2>
                <ol>
                    <li>Korzystanie z pełnej funkcjonalności Serwisu wymaga utworzenia Konta.</li>
                    <li>Rejestracja Konta jest bezpłatna i dobrowolna.</li>
                    <li>Podczas procesu rejestracji Użytkownik zobowiązany jest do podania prawdziwych danych osobowych.
                    </li>
                    <li>Użytkownik jest odpowiedzialny za zabezpieczenie i zachowanie poufności swojego hasła.</li>
                    <li>Użytkownik ponosi odpowiedzialność za wszystkie działania wykonane przy użyciu jego Konta.</li>
                    <li>Operator zastrzega sobie prawo do usunięcia Konta, jeśli Użytkownik nie przestrzega postanowień
                        niniejszego Regulaminu.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§5. Zasady publikowania ogłoszeń</h2>
                <ol>
                    <li>Ogłoszenia publikowane przez Użytkowników muszą być zgodne z prawem polskim i nie mogą naruszać
                        praw osób trzecich.</li>
                    <li>Zabronione jest publikowanie ogłoszeń dotyczących towarów zakazanych, w szczególności:
                        <ul>
                            <li>narkotyków i innych substancji psychoaktywnych;</li>
                            <li>nielegalnych leków i środków farmaceutycznych;</li>
                            <li>broni bez wymaganych zezwoleń;</li>
                            <li>towarów naruszających prawa autorskie;</li>
                            <li>towarów podrabianych (tzw. podróbek).</li>
                        </ul>
                    </li>
                    <li>Ogłoszenia nie mogą zawierać treści obraźliwych, wulgarnych, rasistowskich, propagujących
                        przemoc lub dyskryminację.</li>
                    <li>Sprzedający zobowiązany jest do rzetelnego opisania przedmiotu sprzedaży, w tym wskazania jego
                        wad i uszkodzeń.</li>
                    <li>Operator zastrzega sobie prawo do usunięcia ogłoszenia naruszającego postanowienia Regulaminu
                        bez podania przyczyny.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§6. Transakcje</h2>
                <ol>
                    <li>Serwis umożliwia zawieranie umów sprzedaży między Użytkownikami.</li>
                    <li>Operator nie jest stroną umów zawieranych między Użytkownikami i nie ponosi odpowiedzialności za
                        ich wykonanie.</li>
                    <li>Kupujący i Sprzedający są zobowiązani do wykonania zobowiązań wynikających z zawartej między
                        nimi umowy.</li>
                    <li>Spory między Kupującym a Sprzedającym powinny być rozwiązywane przez strony bez udziału
                        Operatora.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§7. Płatności</h2>
                <ol>
                    <li>Serwis nieumożliwia dokonywania płatności.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§8. Odpowiedzialność</h2>
                <ol>
                    <li>Operator nie ponosi odpowiedzialności za treść ogłoszeń publikowanych przez Użytkowników.</li>
                    <li>Operator nie gwarantuje, że towary oferowane w Serwisie spełniają oczekiwania Kupujących pod
                        względem jakości, bezpieczeństwa czy legalności.</li>
                    <li>Operator nie ponosi odpowiedzialności za szkody wynikające z nieprawidłowego korzystania z
                        Serwisu przez Użytkownika.</li>
                    <li>Operator nie ponosi odpowiedzialności za przerwy w świadczeniu usług wynikające z przyczyn
                        technicznych lub konserwacji systemów.</li>
                    <li>Firma Vulcan sp. z o.o. oraz Rymarz, Zdort, Maruta, Wachta, Gasiński, Her i Wspólnicy Sp.k. nie
                        mają prawa wnosić roszczeń wobec właścicieli Strony ani użytkowników korzystających z jej
                        zasobów. Jakiekolwiek próby dochodzenia roszczeń przez firmę Vulcan sp. z o.o. lub Rymarz,
                        Zdort, Maruta, Wachta, Gasiński, Her i Wspólnicy Sp.k. będą uznane jako cenzura i usuwanie
                        niewygodnych opinii, co stoi w sprzeczności z prawem do wyrażania własnych poglądów, wolnością
                        słowa i art.54 Konstytucji RP.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§9. Ochrona danych osobowych</h2>
                <ol>
                    <li>Administratorem danych osobowych Użytkowników jest Operator.</li>
                    <li>Dane osobowe Użytkowników są przetwarzane zgodnie z przepisami Rozporządzenia Parlamentu
                        Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016 r. w sprawie ochrony osób fizycznych
                        w związku z przetwarzaniem danych osobowych i w sprawie swobodnego przepływu takich danych oraz
                        uchylenia dyrektywy 95/46/WE (RODO).</li>
                    <li>Szczegółowe informacje dotyczące przetwarzania danych osobowych zawarte są w Polityce
                        Prywatności dostępnej w Serwisie.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§10. Własność intelektualna</h2>
                <ol>
                    <li>Wszelkie prawa własności intelektualnej do Serwisu, w tym do jego nazwy, domeny internetowej,
                        oprogramowania oraz układu graficznego przysługują Operatorowi.</li>
                    <li>Korzystanie z Serwisu nie oznacza nabycia jakichkolwiek praw własności intelektualnej do
                        Serwisu.</li>
                    <li>Zabronione jest kopiowanie, modyfikowanie, rozpowszechnianie, transmitowanie lub wykorzystywanie
                        w inny sposób jakichkolwiek treści i baz danych udostępnianych w Serwisie, za wyjątkiem
                        korzystania z nich w ramach dozwolonego użytku.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§11. Zmiany Regulaminu</h2>
                <ol>
                    <li>Operator zastrzega sobie prawo do zmiany Regulaminu z ważnych przyczyn, w szczególności w
                        przypadku:
                        <ul>
                            <li>zmiany przepisów prawa;</li>
                            <li>zmiany zakresu lub formy świadczenia usług;</li>
                            <li>zmiany funkcjonalności Serwisu.</li>
                        </ul>
                    </li>
                    <li>O zmianach Regulaminu Użytkownicy będą informowani poprzez publikację nowej wersji Regulaminu w
                        Serwisie.</li>
                    <li>Zmiany Regulaminu wchodzą w życie po upływie 14 dni od dnia ich publikacji w Serwisie.</li>
                    <li>Korzystanie z Serwisu po wejściu w życie zmian Regulaminu oznacza ich akceptację.</li>
                </ol>
            </div>

            <div class="section">
                <h2>§12. Postanowienia końcowe</h2>
                <ol>
                    <li>W sprawach nieuregulowanych niniejszym Regulaminem zastosowanie mają przepisy prawa polskiego.
                    </li>
                    <li>Wszelkie spory wynikłe na gruncie niniejszego Regulaminu rozstrzygać będzie sąd właściwy dla
                        siedziby Operatora.</li>
                    <li>Jeżeli którekolwiek z postanowień Regulaminu zostanie uznane za nieważne lub nieskuteczne,
                        pozostałe postanowienia Regulaminu pozostają w mocy.</li>
                    <li>Regulamin wchodzi w życie z dniem 10.03.2025.</li>
                </ol>
            </div>
        </div>
    </main>
    <?php include 'footer.php'; ?>