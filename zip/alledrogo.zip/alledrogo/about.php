<!DOCTYPE html>
<html lang="pl">

<head>
    <title>O nas - Alledrogo</title>
    <meta property="og:title" content="O nas - Alledrogo">
    <?php include 'navbar.php'; ?>
    <main style="margin: auto; max-width: 800px;">
        <h1>O Alledrogo</h1>
        <section>
            <h2>Opis</h2>
            <p>Projekt Alledrogo to platforma, która umożliwia użytkownikom kupowanie i sprzedawanie produktów w prosty i bezpieczny sposób. Naszym celem jest stworzenie przyjaznego środowiska dla wszystkich użytkowników.</p>
        </section>
        <section>
            <h2>Zespół</h2>
            <p>Nasz zespół składa się z doświadczonych specjalistów w dziedzinie e-commerce, technologii oraz obsługi klienta.</p>
        </section>
    </main>
    <?php include 'footer.php'; ?>