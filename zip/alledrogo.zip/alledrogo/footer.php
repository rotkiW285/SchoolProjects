<footer>
    <div class="fcol">
        <h2>Alledrogo</h2>
        <a href="#">O nas</a><br>
        <a href="contact">Kontakt</a><br>
        <a href="contact">Reklama</a><br>
        <a href="#">Alledrogo API</a><br>
        <a href="contact">Praca w Alledrogo</a><br>
        <a href="https://ptoszek.pl" target="_blank">Ptoszek</a><br>
        <a href="#">Mapa strony</a><br>
        <a href="karmelek">Karmelek</a>
    </div>
    <div class="fcol">
        <h2>Centrum pomocy</h2>
        <a href="contact">Pomoc dla kupujących</a><br>
        <a href="#">Dla kupujących</a><br>
        <a href="#">Pomoc dla sprzedających</a><br>
        <a href="login">Sprzedawaj na Alledrogo</a><br>
        <a href="contact">Zwrot zakupu</a><br>
        <a href="#">Polityka prywatności mediów społecznościowych</a><br>
        <a href="#">Polityka plików "cookies"</a><br>
        <a href="regulamin">Regulamin</a><br>
    </div>
    <div class="fcol">
        <h2>Serwisy</h2>
        <a href="#">Alledrogo Protect</a><br>
        <a href="#">Akademia Alledrogo</a><br>
        <a href="#">Alledrogo Business</a><br>
        <a href="#">Alledrogo Cash</a><br>
        <a href="#">Alledrogo Pay</a><br>
        <a href="#">Alledrogo Smart!</a><br>
        <a href="#">Archiwum Alledrogo</a><br>
        <a href="#">Karty podarunkowe Alledrogo</a>
    </div>
</footer>
<div class="info">
    &copy; 1410 - 2025 Alledrogo, Wiktor Stawicki. Wszelkie prawa niezastrzeżone.
</div>
</body>
</html>