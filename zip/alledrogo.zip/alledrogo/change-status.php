<?php
session_start();
require 'db_conn.php';

if (!isset($_SESSION['id'])) {
    header("Location: account");
    exit();
}

if (isset($_POST['product_id']) && is_numeric($_POST['product_id']) && isset($_POST['new_status'])) {
    $product_id = $_POST['product_id'];
    $new_status = $_POST['new_status'];
    $user_id = $_SESSION['id'];

    if ($new_status != 'Aktywne' && $new_status != 'Nieaktywne') {
        $_SESSION['message'] = "Nieprawidłowy status produktu.";
        $_SESSION['message_type'] = "error";
        header("Location: account-info");
        exit();
    }

    $check_query = "SELECT product_id FROM products WHERE product_id = '$product_id' AND seller_id = '$user_id'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $update_query = "UPDATE products SET status = '$new_status' WHERE product_id = '$product_id'";
        
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['message'] = "Status ogłoszenia został pomyślnie zmieniony na \"" . $new_status . "\".";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Wystąpił błąd podczas zmiany statusu ogłoszenia.";
            $_SESSION['message_type'] = "error";
        }
    } else {
        $_SESSION['message'] = "Nie masz uprawnień do modyfikacji tego ogłoszenia lub ogłoszenie nie istnieje.";
        $_SESSION['message_type'] = "error";
    }
} else {
    $_SESSION['message'] = "Nieprawidłowy identyfikator produktu lub brak informacji o nowym statusie.";
    $_SESSION['message_type'] = "error";
}

header("Location: account-info");
exit();
?>