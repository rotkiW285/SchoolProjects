function addToCart(productId) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let existingProduct = cart.find((item) => item.id === productId);

  if (existingProduct) {
    existingProduct.quantity += 1;
  } else {
    cart.push({
      id: productId,
      quantity: 1,
    });
  }

  localStorage.setItem("cart", JSON.stringify(cart));

  updateCartCounter();

  alert("Produkt został dodany do koszyka!");
}

function removeFromCart(productId) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  cart = cart.filter((item) => item.id !== productId);

  localStorage.setItem("cart", JSON.stringify(cart));

  updateCartCounter();
  displayCart();
}

function updateQuantity(productId, quantity) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  let product = cart.find((item) => item.id === productId);

  if (product) {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      product.quantity = quantity;
      localStorage.setItem("cart", JSON.stringify(cart));
      displayCart();
    }
  }

  updateCartCounter();
}

function clearCart() {
  localStorage.removeItem("cart");
  updateCartCounter();
  displayCart();
}

function displayCart() {
  const cartContainer = document.getElementById("cart-container");
  if (!cartContainer) return;

  const cart = JSON.parse(localStorage.getItem("cart")) || [];

  if (cart.length === 0) {
    cartContainer.innerHTML = "<center><h2>Twój koszyk jest pusty</h2></center>";
    return;
  }

  fetchCartProducts(cart);
}

function fetchCartProducts(cart) {
  const productIds = cart.map((item) => item.id).join(",");

  if (!productIds) {
    displayEmptyCart();
    return;
  }

  fetch("get_cart_products.php?ids=" + productIds)
    .then((response) => response.json())
    .then((products) => {
      renderCartItems(products, cart);
    })
    .catch((error) => {
      console.error("Błąd podczas pobierania danych produktów:", error);
      document.getElementById("cart-container").innerHTML =
        "<p>Błąd podczas ładowania koszyka</p>";
    });
}

function renderCartItems(products, cartItems) {
  const cartContainer = document.getElementById("cart-container");
  let totalPrice = 0;
  let cartHTML = '<div class="cart-items">';

  products.forEach((product) => {
    const cartItem = cartItems.find((item) => item.id === product.product_id);
    if (cartItem) {
      const itemTotal = product.price * cartItem.quantity;
      totalPrice += itemTotal;

      cartHTML += `
                <div class="cart-item">
                    <div class="cart-item-image">
                        <img src="assets/products/${product.image_url}" alt="${product.name}">
                    </div>
                    <div class="cart-item-details">
                        <h3>${product.name}</h3>
                        <p>${product.price} zł</p>
                        <div class="quantity-controls">
                            <button onclick="updateQuantity('${
                              product.product_id
                            }', ${cartItem.quantity - 1})">-</button>
                            <span>${cartItem.quantity}</span>
                            <button onclick="updateQuantity('${
                              product.product_id
                            }', ${cartItem.quantity + 1})">+</button>
                        </div>
                        <p>Razem: ${itemTotal.toFixed(2)} zł</p>
                        <button class="remove-item" onclick="removeFromCart('${product.product_id}')">Usuń</button>
                    </div>
                </div>
            `;
    }
  });

  cartHTML += "</div>";

  cartHTML += `
        <div class="cart-summary">
            <h3>Podsumowanie</h3>
            <p>Łączna kwota: <strong>${totalPrice.toFixed(2)} zł</strong></p>
            <button id="checkout-button" class="checkout-button">Przejdź do płatności</button>
            <button onclick="clearCart()" class="clear-cart">Wyczyść koszyk</button>
        </div>
    `;

  cartContainer.innerHTML = cartHTML;

  document
    .getElementById("checkout-button")
    .addEventListener("click", function () {
      alert("Funkcja płatności nie została jeszcze zaimplementowana");
    });
}

function displayEmptyCart() {
  const cartContainer = document.getElementById("cart-container");
  cartContainer.innerHTML = "<center><h2>Twój koszyk jest pusty</h2></center>";
}

function updateCartCounter() {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const cartCounter = document.getElementById("cart-counter");

  if (cartCounter) {
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);

    if (totalItems > 0) {
      cartCounter.textContent = totalItems;
      cartCounter.style.display = "flex";
    } else {
      cartCounter.style.display = "none";
    }
  }
}

function showNotification(message) {
  let notification = document.getElementById("cart-notification");

  if (!notification) {
    notification = document.createElement("div");
    notification.id = "cart-notification";
    document.body.appendChild(notification);
  }

  notification.textContent = message;
  notification.classList.add("show");

  setTimeout(function () {
    notification.classList.remove("show");
  }, 3000);
}

document.addEventListener("DOMContentLoaded", function () {
  updateCartCounter();

  if (document.getElementById("cart-container")) {
    displayCart();
  }
});
