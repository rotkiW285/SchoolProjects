function validateProduct() {
  let isValid = true;

  const priceError = document.getElementById("price-error");
  const nameError = document.getElementById("name-error");
  const name = document.getElementById("name").value;

  priceError.textContent = "";
  nameError.textContent = "";

  if (name.length > 100) {
    nameError.textContent ="Nazwa produktu nie może być dłuższa niż 150 znaków";
    isValid = false;
  }

  if (priceField < 0) {
    priceError.textContent = "Cena nie może być ujemna";
    isValid = false;
  } else if (priceField > 8) {
    priceError.textContent = "Ma być drogo, ale nie aż tak!";
    isValid = false;
  }

  return isValid;
}
