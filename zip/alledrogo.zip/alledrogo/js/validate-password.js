function validateForm() {
  let isValid = true;

  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirm_password").value;
  const passwordError = document.getElementById("password-error");
  const priceField = document.getElementById("price").value;

  passwordError.textContent = "";
  priceError.textContent = "";

  if (password.length < 8) {
    passwordError.textContent = "Hasło musi mieć co najmniej 8 znaków";
    isValid = false;
  } else if (!/\d/.test(password)) {
    passwordError.textContent = "Hasło musi zawierać co najmniej jedną cyfrę";
    isValid = false;
  } else if (password !== confirmPassword) {
    passwordError.textContent = "Hasła nie pasują do siebie";
    isValid = false;
  }

  const terms = document.getElementById("terms");
  const termsError = document.getElementById("terms-error");
  termsError.textContent = "";

  if (!terms.checked) {
    termsError.textContent = "Musisz zaakceptować regulamin";
    isValid = false;
  }

  return isValid;
}

function validatePassword(password) {
  if (password.length < 8) {
    return false;
  }

  if (password.length > 60) {
    return false;
  }

  if (!/[A-Z]/.test(password)) {
    return false;
  }

  if (!/[a-z]/.test(password)) {
    return false;
  }

  if (!/[0-9]/.test(password)) {
    return false;
  }

  return true;
}

function getPasswordErrorMessage(password) {
  let errors = [];

  if (password.length < 8) {
    errors.push("co najmniej 8 znaków");
  }

  if (!/[A-Z]/.test(password)) {
    errors.push("co najmniej jedną dużą literę");
  }

  if (!/[a-z]/.test(password)) {
    errors.push("co najmniej jedną małą literę");
  }

  if (!/[0-9]/.test(password)) {
    errors.push("co najmniej jedną cyfrę");
  }

  if (errors.length === 0) {
    return "";
  }

  return "Hasło powinno zawierać " + errors.join(", ") + ".";
}
