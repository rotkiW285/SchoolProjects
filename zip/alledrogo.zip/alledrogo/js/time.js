function updateTime() {
    const now = new Date();
    const formattedTime = now.toLocaleString('pl-PL', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    document.getElementById('time').innerText = formattedTime;
}

setInterval(updateTime, 1000);
window.onload = updateTime;