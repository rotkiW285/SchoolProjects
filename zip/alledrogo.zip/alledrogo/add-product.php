<?php
session_start();
include 'db_conn.php';

if (!isset($_SESSION['id'])) {
    header('Location: account?error=Zaloguj się, aby dodać produkt');
    exit();
}

$categories = [];
$sql = "SELECT category_id, name FROM categories";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $categories[] = $row;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];
    $seller_id = $_SESSION['id'];

    $image_url = "default.webp";

    if (isset($_FILES['image']) && $_FILES['image']['name'] != "") {
        $target_dir = "assets/products/";

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $new_filename = time() . "_" . rand(1000, 9999) . "." . $file_extension;
        $target_file = $target_dir . $new_filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image_url = $new_filename;
        } else {
            $error = "Nie udało się przesłać zdjęcia.";
        }
    }

    $status = 'Aktywne';

    $sql = "INSERT INTO products (name, description, price, image_url, category_id, created_at, seller_id, status) 
            VALUES ('$name', '$description', $price, '$image_url', $category_id, NOW(), $seller_id, '$status')";

    if ($conn->query($sql) === TRUE) {
        $message = "Produkt dodany pomyślnie!";
        $name = $description = "";
        $price = $category_id = 0;
    } else {
        $error = "Błąd podczas dodawania produktu: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo - Dodaj produkt</title>
    <meta property="og:title" content="Alledrogo - Dodaj produkt">
    <link rel="stylesheet" href="css/register.css">
    <script src="js/validate-product.js"></script>
    <?php include 'navbar.php'; ?>
    <main>

        <?php if (isset($message)): ?>
            <div class="message-success"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="message-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="post" enctype="multipart/form-data onsubmit="return validateProduct()">
            <div class="register-container">
                <h2>Dodaj produkt</h2>
                <label for="name">Nazwa produktu:</label>
                <input type="text" id="name" name="name" maxlength="100" value="<?php echo isset($name) ? $name : ''; ?>" required>
                <p id="name-error"></p>
                <label for="description">Opis produktu:</label>
                <textarea id="description" name="description" required><?php echo isset($description) ? $description : ''; ?></textarea><br>

                <label for="price">Cena (PLN):</label>
                <input type="number" id="price" name="price" step="0.01" maxlength="8" value="<?php echo isset($price) ? $price : ''; ?>" required><br>
                <p id="price-error"></p>
                <label for="category_id">Kategoria:</label>
                <select id="category_id" name="category_id" required>
                    <option value="">Wybierz kategorię</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['category_id']; ?>">
                            <?php echo $category['name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select><br><br>

                <label for="image">Zdjęcie produktu (opcjonalnie):</label>
                <input type="file" id="image" name="image" accept="image/*">
                <small>Dozwolone formaty: JPG, PNG, GIF, WEBP</small><br><br>

                <button type="submit" id="submit" class="btn-submit">Dodaj produkt</button>
            </div>
        </form>
    </main>
    <?php include 'footer.php'; ?>