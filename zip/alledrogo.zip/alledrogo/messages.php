<!DOCTYPE html>
<html lang="pl">

<head>
    <title>Alledrogo - Moje wiadomości</title>
    <meta property="og:title" content="Alledrogo - Moje wiadomości">
    <link rel="stylesheet" href="css/messages.css">
    <?php include 'navbar.php'; ?>
    <main>
        <?php
        include 'db_conn.php';

        if (!isset($_SESSION['id'])) {
            echo '<div class="must-be-signed-in">';
            echo '<div class="message-error">Musisz być zalogowany, aby przeglądać wiadomości.</div><br>';
            echo '<button id="submit" onclick="window.location.href=\'account\'">Zaloguj się</button>';
            echo '</div>';
        } else {
            $user_id = $_SESSION['id'];

            if (isset($_POST['reply']) && isset($_POST['parent_id']) && isset($_POST['receiver_id']) && isset($_POST['product_id'])) {
                $parent_id = $_POST['parent_id'];
                $receiver_id = $_POST['receiver_id'];
                $product_id = $_POST['product_id'];
                $title = isset($_POST['title']) ? "RE: " . $_POST['title'] : "Odpowiedź";
                $content = trim($_POST['content']);

                if (!empty($content)) {
                    $sql = "INSERT INTO messages (sender_id, receiver_id, product_id, title, content, parent_message_id) 
                            VALUES ('$user_id', '$receiver_id', '$product_id', '$title', '$content', '$parent_id')";

                    if (mysqli_query($conn, $sql)) {
                        echo '<div class="message-success">Odpowiedź została wysłana pomyślnie!</div>';
                    } else {
                        echo '<div class="message-error">Wystąpił błąd podczas wysyłania odpowiedzi: ' . mysqli_error($conn) . '</div>';
                    }
                } else {
                    echo '<div class="message-error">Treść wiadomości nie może być pusta.</div>';
                }
            }

            if (isset($_GET['read']) && is_numeric($_GET['read'])) {
                $message_id = $_GET['read'];
                $sql = "UPDATE messages SET status = 'read' WHERE message_id = '$message_id' AND receiver_id = '$user_id'";
                mysqli_query($conn, $sql);
            }

            $sql = "SELECT messages.*, 
                    users_sender.username as sender_name,
                    users_receiver.username as receiver_name,
                    products.name as product_name,
                    products.image_url
                    FROM messages 
                    JOIN users users_sender ON messages.sender_id = users_sender.user_id
                    JOIN users users_receiver ON messages.receiver_id = users_receiver.user_id
                    LEFT JOIN products ON messages.product_id = products.product_id
                    WHERE (messages.receiver_id = '$user_id' OR messages.sender_id = '$user_id')
                    ORDER BY messages.send_date DESC";

            $result = mysqli_query($conn, $sql);

            echo '<div class="messages-container">';
            echo '<h1>Moje wiadomości</h1>';

            echo '<div id="received" class="message-list">';
            echo '<h2>Otrzymane wiadomości</h2>';

            $received_count = 0;

            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    if ($row['receiver_id'] == $user_id) {
                        $received_count++;

                        $message_class = ($row['status'] == 'unread') ? 'message-unread' : 'message-read';

                        echo '<div class="message-item ' . $message_class . '">';
                        echo '<div class="message-header">';
                        echo '<div class="message-from">Od: ' . htmlspecialchars($row['sender_name']) . '</div>';
                        echo '<div class="message-date">' . date('d.m.Y H:i', strtotime($row['send_date'])) . '</div>';
                        echo '</div>';

                        echo '<div class="message-title">';
                        if ($row['status'] == 'unread') {
                            echo '<span class="unread-badge">Nowa</span> ';
                        }
                        echo htmlspecialchars($row['title']) . '</div>';

                        if (!empty($row['product_id'])) {
                            echo '<div class="message-product">';
                            if (!empty($row['image_url'])) {
                                echo '<img src="assets/products/' . htmlspecialchars($row['image_url']) . '" alt="' . htmlspecialchars($row['product_name']) . '">';
                            }
                            echo '<span>Dotyczy: ' . htmlspecialchars($row['product_name']) . '</span>';
                            echo '</div>';
                        }

                        echo '<div class="message-content">' . nl2br(htmlspecialchars($row['content'])) . '</div>';

                        echo '<div class="message-actions">';
                        echo '<button class="reply-btn" onclick="toggleReplyForm(' . $row['message_id'] . ')">Odpowiedz</button>';
                        echo '</div>';

                        echo '<div id="reply-form-' . $row['message_id'] . '" class="reply-form" style="display: none;">';
                        echo '<form method="post" action="">';
                        echo '<input type="hidden" name="parent_id" value="' . $row['message_id'] . '">';
                        echo '<input type="hidden" name="receiver_id" value="' . $row['sender_id'] . '">';
                        echo '<input type="hidden" name="product_id" value="' . $row['product_id'] . '">';
                        echo '<input type="hidden" name="title" value="' . htmlspecialchars($row['title']) . '">';

                        echo '<textarea name="content" rows="4" placeholder="Twoja odpowiedź..." required></textarea>';
                        echo '<button type="submit" name="reply" class="reply-btn">Wyślij</button>';
                        echo '</form>';
                        echo '</div>';

                        echo '</div>';
                    }
                }

                if ($received_count == 0) {
                    echo '<p class="no-messages">Brak otrzymanych wiadomości.</p>';
                }
            }

            echo '</div>';

            echo '<div id="sent" class="message-list">';
            echo '<h2>Wysłane wiadomości</h2>';

            $sent_count = 0;

            $result = mysqli_query($conn, $sql);

            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    if ($row['sender_id'] == $user_id) {
                        $sent_count++;

                        echo '<div class="message-item">';
                        echo '<div class="message-header">';
                        echo '<div class="message-to">Do: ' . htmlspecialchars($row['receiver_name']) . '</div>';
                        echo '<div class="message-date">' . date('d.m.Y H:i', strtotime($row['send_date'])) . '</div>';
                        echo '</div>';

                        echo '<div class="message-title">' . htmlspecialchars($row['title']) . '</div>';

                        if (!empty($row['product_id'])) {
                            echo '<div class="message-product">';
                            if (!empty($row['image_url'])) {
                                echo '<img src="assets/products/' . htmlspecialchars($row['image_url']) . '" alt="' . htmlspecialchars($row['product_name']) . '">';
                            }
                            echo '<span>Dotyczy: ' . htmlspecialchars($row['product_name']) . '</span>';
                            echo '</div>';
                        }

                        echo '<div class="message-content">' . nl2br(htmlspecialchars($row['content'])) . '</div>';
                        echo '</div>';
                    }
                }

                if ($sent_count == 0) {
                    echo '<p class="no-messages">Brak wysłanych wiadomości.</p>';
                }
            }

            echo '</div>';
            echo '</div>';
        }

        mysqli_close($conn);
        ?>

        <script>
            function toggleReplyForm(messageId) {
                const replyForm = document.getElementById('reply-form-' + messageId);
                if (replyForm.style.display === 'none') {
                    replyForm.style.display = 'block';
                } else {
                    replyForm.style.display = 'none';
                }

                fetch('messages?read=' + messageId)
                    .then(response => {
                        const messageItem = replyForm.closest('.message-item');
                        if (messageItem) {
                            messageItem.classList.remove('message-unread');
                            messageItem.classList.add('message-read');

                            const unreadBadge = messageItem.querySelector('.unread-badge');
                            if (unreadBadge) {
                                unreadBadge.remove();
                            }
                        }
                    });
            }
        </script>
    </main>
    <?php include 'footer.php'; ?>