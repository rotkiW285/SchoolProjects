<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: account");
    exit();
}

$message = '';
$error = '';
if (isset($_GET['message'])) {
    if ($_GET['message'] == 'password_changed') {
        $message = 'Hasło zostało pomyślnie zmienione.';
    }
}

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo - Moje konto</title>
    <meta property="og:title" content="Alledrogo - moje konto">
    <link rel="stylesheet" href="css/orders.css">
    <?php include 'navbar.php'; ?>
    <main>
        <center>
            <div class="form-wrapper">
                <?php if (!empty($message)): ?>
                    <div class="success-message"><?php echo $message; ?></div>
                <?php endif; ?>
                <?php if (!empty($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>

                <h1>Moje Alledrogo</h1>
                <div class="acc-info">
                    <?php
                    require 'db_conn.php';

                    $user_id = $_SESSION['id'];
                    
                    $zapytanie = "SELECT username, email, first_name, last_name, created_at FROM users WHERE user_id = '$user_id'";
                    $wynik = mysqli_query($conn, $zapytanie);
                    $user = mysqli_fetch_assoc($wynik);

                    echo "<p><strong>Nazwa użytkownika: </strong>" . htmlspecialchars($user['username']) . "</p>";
                    echo "<p><strong>Email: </strong>" . htmlspecialchars($user['email']) . "</p>";
                    echo "<p><strong>Imię i Nazwisko: </strong>" . htmlspecialchars($user['first_name']) . " " . htmlspecialchars($user['last_name']) . "</p>";
                    echo "<p><strong>Data rejestracji: </strong>" . htmlspecialchars($user['created_at']) . "</p>";
                    ?>

                    <a href="account-management" id="submit">Zarządzaj kontem</a>
                </div>
            </div>
                <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                    <a href="admin" id="submit">Panel administratora</a><br><br>
                <?php endif; ?>

        </center>

        <?php
        $user_id = $_SESSION['id'];
        
        $query = "SELECT * FROM products WHERE seller_id = '$user_id'";
        $result = mysqli_query($conn, $query);

        function displayProductsTable($products, $tableType)
        {
            if (count($products) > 0) {
                echo '<center><table class="orders-table">
                    <thead>
                        <tr>
                            <th>ID produktu</th>
                            <th>Nazwa</th>
                            <th>Cena</th>
                            <th>Data dodania</th>
                            <th>Akcje</th>
                        </tr>
                    </thead>
                    <tbody>';

                foreach ($products as $row) {
                    $buttonText = ($row['status'] == 'Aktywne') ? 'Dezaktywuj' : 'Aktywuj';
                    $buttonClass = ($row['status'] == 'Aktywne') ? 'deactivate-btn' : 'activate-btn';
                    $newStatus = ($row['status'] == 'Aktywne') ? 'Nieaktywne' : 'Aktywne';

                    echo '<tr>
                        <td>' . htmlspecialchars($row['product_id']) . '</td>
                        <td>' . htmlspecialchars($row['name']) . '</td>
                        <td>' . htmlspecialchars($row['price']) . ' zł</td>
                        <td>' . htmlspecialchars($row['created_at']) . '</td>
                        <td>
                            <form method="post" action="change-status.php">
                                <input type="hidden" name="product_id" value="' . $row['product_id'] . '">
                                <input type="hidden" name="new_status" value="' . $newStatus . '">
                                <button type="submit" class="' . $buttonClass . '">' . $buttonText . '</button>
                            </form>
                        </td>
                    </tr>';
                }

                echo '</tbody></table></center>';
            } else {
                echo '<center><p>Brak ' . $tableType . ' ogłoszeń.</p></center>';
            }
        }

        $active_products = [];
        $inactive_products = [];

        $products_query = "SELECT * FROM products WHERE seller_id = '$user_id' ORDER BY created_at DESC";
        $products_result = mysqli_query($conn, $products_query);

        if (mysqli_num_rows($products_result) > 0) {
            while ($row = mysqli_fetch_assoc($products_result)) {
                if ($row['status'] == 'Aktywne') {
                    $active_products[] = $row;
                } else {
                    $inactive_products[] = $row;
                }
            }
        }

        echo "<center><h2>Aktywne ogłoszenia</h2></center>";
        displayProductsTable($active_products, 'aktywnych');

        echo "<center><h2>Nieaktywne ogłoszenia</h2></center>";
        displayProductsTable($inactive_products, 'nieaktywnych');

        mysqli_close($conn);
        ?>
        </div>
    </main>
    <?php include 'footer.php'; ?>