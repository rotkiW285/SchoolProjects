<?php
session_start();
require 'db_conn.php';

if (!isset($_SESSION['id']) || $_SESSION['is_admin'] != 1) {
    header("Location: /");
    exit();
}

$user_id = $_SESSION['id'];
$admin_check_query = "SELECT is_admin FROM users WHERE user_id = $user_id";
$result = $conn->query($admin_check_query);
$user_data = $result->fetch_assoc();

if (!$result || !$user_data || $user_data['is_admin'] != 1) {
    header("Location: /");
    exit();
}

$message = '';
$error = '';

if (isset($_GET['action'])) {
    if ($_GET['action'] == 'delete_user' && isset($_GET['user_id'])) {
        $user_id = (int)$_GET['user_id'];
        $delete_query = "DELETE FROM users WHERE user_id = $user_id";

        if ($conn->query($delete_query)) {
            $message = 'Użytkownik został usunięty.';
        } else {
            $error = 'Wystąpił błąd podczas usuwania użytkownika.';
        }
    }

    if ($_GET['action'] == 'delete_product' && isset($_GET['product_id'])) {
        $product_id = (int)$_GET['product_id'];
        $delete_query = "DELETE FROM products WHERE product_id = $product_id";

        if ($conn->query($delete_query)) {
            $message = 'Produkt został usunięty.';
        } else {
            $error = 'Wystąpił błąd podczas usuwania produktu.';
        }
    }
}

$users_query = "SELECT * FROM users";
$users_result = $conn->query($users_query);

$products_query = "SELECT * FROM products";
$products_result = $conn->query($products_query);
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin.css">
    <title>Panel Administratora Alledrogo</title>
</head>
<body>
    <a href="index.php" class="back-button">Powrót do strony głównej</a>

    <h1>Panel Administratora Alledrogo</h1>

    <?php
    if (isset($_GET['error'])) {
        echo '<div class="message-error">' . htmlspecialchars($_GET['error']) . '</div>';
    }

    if (isset($_GET['success'])) {
        echo '<div class="message-success">' . htmlspecialchars($_GET['success']) . '</div>';
    }
    ?>

    <h2>Użytkownicy</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nazwa użytkownika</th>
                <th>Email</th>
                <th>Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($user = $users_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['user_id']); ?></td>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td>
                        <a href="?action=delete_user&user_id=<?php echo $user['user_id']; ?>"
                            onclick="return confirm('Czy na pewno chcesz usunąć tego użytkownika?');">Usuń</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>Produkty</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nazwa</th>
                <th>Cena</th>
                <th>Status</th>
                <th>Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($product = $products_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($product['product_id']); ?></td>
                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                    <td><?php echo htmlspecialchars($product['price']); ?> zł</td>
                    <td><?php echo htmlspecialchars($product['status']); ?></td>
                    <td>
                        <a href="?action=delete_product&product_id=<?php echo $product['product_id']; ?>"
                            onclick="return confirm('Czy na pewno chcesz usunąć ten produkt?');">Usuń</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
<?php
mysqli_close($conn);
?>