<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Alledrogo - Kontakt ze sprzedającym</title>
    <meta property="og:title" content="Alledrogo - Kontakt ze sprzedającym">
    <link rel="stylesheet" href="css/messages.css">
    <?php include 'navbar.php'; ?>

    <main>
        <?php
        include 'db_conn.php';

        if (!isset($_SESSION['id'])) {
            echo '<div class="must-be-signed-in">';
            echo '<div class="message-error">Musisz być zalogowany, aby wysłać wiadomość do sprzedającego.</div><br>';
            echo '<button id="submit" onclick="window.location.href=\'account\'">Zaloguj się</button>';
            echo '</div>';
        } else {
            if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
                echo '<div class="message-error">Nieprawidłowy identyfikator produktu.</div>';
            } else {
                $product_id = $_GET['id'];
                $sender_id = $_SESSION['id'];

                $sql = "SELECT products.*, users.user_id as seller_id, users.username as seller_name 
                        FROM products, users 
                        WHERE products.seller_id = users.user_id 
                        AND products.product_id = $product_id";

                $result = mysqli_query($conn, $sql);

                if ($result && mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_assoc($result);
                    $receiver_id = $row['seller_id'];

                    if ($sender_id == $receiver_id) {
                        echo '<div class="message-error">Nie możesz wysłać wiadomości do siebie.</div>';
                    } else {
                        echo '<div class="messages-container">';
                        echo '<h1>Kontakt ze sprzedającym</h1>';
                        echo '<div class="product-info-small">';
                        echo '<img src="assets/products/' . $row["image_url"] . '" alt="' . $row["name"] . '">';
                        echo '<div class="product-title">' . $row["name"] . '</div>';
                        echo '<div class="product-price">' . number_format($row["price"], 2) . ' zł</div>';
                        echo '<div class="seller-name">Sprzedający: ' . $row["seller_name"] . '</div>';
                        echo '</div>';

                        if (isset($_POST['send'])) {
                            $title = trim($_POST['title']);
                            $content = trim($_POST['content']);

                            if (empty($title) || empty($content)) {
                                echo '<div class="message-error">Uzupełnij wszystkie pola formularza.</div>';
                            } else {
                                $sql = "INSERT INTO messages (sender_id, receiver_id, product_id, title, content) 
                                        VALUES ($sender_id, $receiver_id, $product_id, '$title', '$content')";

                                if (mysqli_query($conn, $sql)) {
                                    echo '<div class="message-success">Wiadomość została wysłana pomyślnie!</div>';
                                } else {
                                    echo '<div class="message-error">Wystąpił błąd podczas wysyłania wiadomości: ' . mysqli_error($conn) . '</div>';
                                }
                            }
                        }

                        echo '<form method="post" action="">';
                        echo '<div class="form-group">';
                        echo '<label for="title">Tytuł:</label>';
                        echo '<input type="text" id="title" name="title" required value="Pytanie o: ' . $row["name"] . '">';
                        echo '</div>';

                        echo '<div class="form-group">';
                        echo '<label for="content">Treść wiadomości:</label>';
                        echo '<textarea id="content" name="content" required rows="6"></textarea>';
                        echo '</div>';

                        echo '<div class="form-group">';
                        echo '<button type="submit" name="send" class="reply-btn">Wyślij wiadomość</button>';
                        echo '</div>';
                        echo '</form>';
                        echo '</div>';
                    }
                } else {
                    echo '<div class="must-be-signed-in">';
                    echo '<div class="message-error">Produkt nie istnieje.</div>';
                    echo '</div>';
                }
            }
        }

        mysqli_close($conn);
        ?>
    </main>
    <?php include 'footer.php'; ?>