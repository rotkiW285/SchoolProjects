-- phpMyAdmin SQL Dump
-- version 5.2.1deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 26, 2025 at 08:49 AM
-- Wersja serwera: 10.11.6-MariaDB-0+deb12u1
-- Wersja PHP: 8.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alledrogo`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`) VALUES
(1, 'Elektronika'),
(2, 'Moda'),
(3, 'Dom i ogród'),
(4, 'Sport i hobby'),
(5, 'Dziecko'),
(6, 'Uroda'),
(7, 'Kultura i rozrywka'),
(8, 'Motoryzacja'),
(9, 'Zdrowie'),
(10, 'Inne');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `send_date` datetime DEFAULT current_timestamp(),
  `status` enum('unread','read') DEFAULT 'unread',
  `parent_message_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `sender_id`, `receiver_id`, `product_id`, `title`, `content`, `send_date`, `status`, `parent_message_id`) VALUES
(1, 1, 4, 56, 'Pytanie o: Renault Modus', 'Dzień dobry, jest aż tak źle?', '2025-03-12 00:09:51', 'read', NULL),
(2, 4, 1, 56, 'RE: Pytanie o: Renault Modus', 'witam, ***** tak', '2025-03-12 10:12:33', 'read', 1),
(3, 1, 4, 56, 'RE: RE: Pytanie o: Renault Modus', 'zajebiscie, kupuje', '2025-03-12 10:13:16', 'unread', 2),
(4, 1, 12, 66, 'Pytanie o: NAJLEPSZY KĄKUTER DLA GRACZA', 'Czy ten kąkuter jest szypki?', '2025-03-26 09:32:28', 'unread', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_url` varchar(255) DEFAULT 'default.webp',
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_sponsored` tinyint(1) NOT NULL DEFAULT 0,
  `seller_id` int(11) DEFAULT NULL,
  `status` enum('Aktywne','Nieaktywne') DEFAULT 'Aktywne'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `description`, `price`, `image_url`, `category_id`, `created_at`, `is_sponsored`, `seller_id`, `status`) VALUES
(2, 'Lenovo R24e', 'Monitor', 7666.00, 'lenovo-r24e.webp', 1, '2025-02-11 15:45:06', 0, 2, 'Aktywne'),
(4, 'Samsung Galaxy Buds3 Pro srebrne', 'Słuchawki', 2137.00, 'samsung-galaxy-buds3.webp', 1, '2025-02-11 16:07:32', 0, 1, 'Aktywne'),
(6, 'Pampers Pieluszki Premium Care 4 Maxi 2x104 szt.', 'Zapas łącznie 208 sztuk\r\n\r\nNajlepszy komfort i ochrona wrażliwej skóry od Pampers – testowane i zatwierdzone uśmiechem dzieci!', 5279.98, 'pampers.webp', 5, '2025-02-11 16:10:29', 0, 1, 'Aktywne'),
(7, 'G4M3R ELITE R7-9800X3D / 64GB / 2TB / RTX5090', 'Komputer gamingowy', 20000.00, 'G4M3R-elite.webp', 1, '2025-02-11 14:45:06', 0, 1, 'Aktywne'),
(8, 'MSI GeForce RTX 4060 Ventus 2X', 'Karta graficzna', 69420.00, 'msi-rtx-4060-oc-8gb.webp', 1, '2025-02-11 14:45:06', 0, 1, 'Aktywne'),
(9, 'Acer Nitro V16 R5-8645HS/16GB/512 RTX4050 165Hz', 'Laptop gejmingowy', 79846.00, 'acer-nitro-v16.webp', 1, '2025-02-11 15:08:38', 0, 1, 'Aktywne'),
(10, 'Powiększenie piekielnika', 'Powiększe twojego piekielnika!', 7985.00, 'piekielnik.png', 6, '2025-03-04 20:30:59', 1, 1, 'Aktywne'),
(11, 'T-shirt Casual', 'Bawełniany t-shirt w modnym kroju, idealny do codziennego użytku.', 249.99, 'tshirt.jpeg', 2, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(12, 'Sukienka koktajlowa', 'Elegancka sukienka idealna na wieczorne wyjście.', 2199.99, 'koktajlowa-sukienka-z-rozkloszowanym-dolem-i-haftowana-gora-z-cekinami-2-1024x1536-1947458143.jpg', 2, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(13, 'Buty sportowe', 'Wygodne buty do biegania i treningu.', 5249.99, 'pol_pl_Meskie-Buty-Sportowe-Puma-Descendant-v3-Running-Niebieskie-387_7-3827586194.jpg', 2, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(14, 'Stolik ogrodowy', 'Solidny stolik z drewna do ogrodu, idealny na letnie spotkania.', 299.99, '141c03b7c84d3b7bb8b3b6a06b9ebd7c-1332844183.jpeg', 3, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(15, 'Fotel ogrodowy', 'Komfortowy fotel do relaksu na tarasie.', 499.99, 'fotel-ogrodowy-3588117918.jpg', 3, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(16, 'Lampka solarna', 'Oświetlenie solarne do ogrodu, ekologiczne i energooszczędne.', 989.99, 'lampa-solarna-kula-lampy-solarne-lampy-solarne-do-ogrodu-lampa-solarna-led-2566129521.jpg', 3, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(17, 'Rower górski', 'Wysokiej klasy rower górski dla miłośników aktywnego wypoczynku.', 2499.99, '662c5a914265b016a7f4f7d13e20-952753369.jpg', 4, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(18, 'Namiot turystyczny', 'Lekki namiot idealny na biwak i wycieczki.', 399.99, 'pol_pl_Namiot-turystyczny-Abarqs-VIGO-4A-SZARY-4-osobowy-14183_2-173322464.jpg', 4, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(19, 'Wózek dziecięcy', 'Praktyczny wózek dziecięcy z regulowanym oparciem.', 899.99, '7238b5248cc1ace825827c1df3b38359-254754125.jpg', 5, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(20, 'Zestaw klocków', 'Kolorowy zestaw klocków rozwijający kreatywność.', 59.99, 'th-2623298387.jpg', 5, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(21, 'Krem nawilżający', 'Luksusowy krem do twarzy z naturalnymi składnikami, idealny na każdą porę roku, redukujący pojemność portfela.', 79.99, '362860__dermika_revisage__nawilzajacy_krem_na_dzien_i_na_noc_30_50_ml__wb__2__reviewed__p-1722890666.png', 6, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(22, 'Perfumy damskie', 'Subtelne perfumy idealne na każdą okazję.', 299.99, 'perfum.png', 6, '2025-03-05 07:34:46', 1, 1, 'Aktywne'),
(23, 'Gra planszowa', 'Ciekawa gra planszowa dla całej rodziny, rozwijająca strategiczne myślenie.', 59.99, 'Chinczyk1-1080-761933541.jpg', 7, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(24, 'Bilet do teatru', 'Bilet na spektakl do wybranej lokalnej sceny teatralnej.', 89.99, 'bilety-do-teatru-kwadrat-warszawa-563029840-3920659327.jpg', 7, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(25, 'Książka \"Tajemnica Piwnica Mydla\"', 'Najlepiej sprzedająca się książka roku.', 59.99, 'PIWNICA-MYDLA.png', 7, '2025-03-05 07:34:46', 0, 2, 'Aktywne'),
(26, 'Dywaniki samochodowe', 'Wysokiej jakości dywaniki do samochodu, łatwe do utrzymania w czystości.', 129.99, '1024x1024x0x6322f928e7e7c-1004432158.jpg', 8, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(27, 'Felgi aluminiowe', 'Zestaw 4 felg aluminiowych o nowoczesnym designie.', 8799.99, 'pol_pl_Felgi-aluminiowe-16cali-Hyundai-Getz-i20-4x100-ET40-22265_5-1790302173.jpg', 8, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(28, 'Akumulator samochodowy', 'Wysokiej wydajności akumulator do samochodu.', 4349.99, 'akumulator-premium-black-12v-1_2494-3308952280.jpg', 8, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(29, 'Suplement diety', 'Totalnie nic nie robi, ale za to jest drogi.', 379.99, '910d9fc84d978a7a1eab77107873-2482584338.jpg', 9, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(30, 'Termometr bezdotykowy', 'Precyzyjny termometr bezdotykowy dla całej rodziny.', 5129.99, 'termometr_bezdotykowy_pempa_t200-4041066637.jpg', 9, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(31, 'Masażer elektryczny', 'Urządzenie do relaksacyjnego masażu całego ciała.', 499.99, 'masazer-elektryczny-wibracyjny-glowy-tens-migrena-stres-bol-8-progr-360-b-iext149936547-367522006.jpg', 9, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(32, 'Kubek kawowy', 'Unikalny kubek z oryginalnym wzorem, doskonały do porannej kawy.', 419.99, 'kubek-kawowy-dla-nauczycielki-niemieckiego-408833064.jpg', 10, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(33, 'Zestaw narzędzi', 'Kompletny zestaw narzędzi do majsterkowania w domu.', 4199.99, 'ZESTAW-163-NARZEDZI-W-WALIZCE-BETA-2056E-E-20-3573218978.jpg', 10, '2025-03-05 07:34:46', 0, 1, 'Aktywne'),
(34, 'Plecak turystyczny', ' Plecak turystyczny, pojemny i wygodny.', 299.99, 'plecak-turystyczny-quechua-arpenaz-nh100-30-litrow-3243130233.jpg', 4, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(35, 'Kurtka outdoorowa', ' Kurtka outdoorowa, chroni przed zimnem i wiatrem.', 499.99, 'kurtka-pikowana-outdoorowa-3093280598.jpg', 4, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(36, 'Krzesełko dziecięce', ' Krzesełko dziecięce, idealne do nauki siedzenia.', 1489.99, '3_max-3872464988.jpg', 5, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(37, 'Rower dziecięcy', ' Rower dziecięcy, idealny dla małych odkrywców.', 299.99, 'Rower-dzieciecy-Romet-Tom-16-czarno-czerwony-1-1536x1152-3520370830.jpg', 5, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(38, 'Szampon', ' Szampon, delikatnie oczyszczający włosy.', 29.99, 'pol_pl_Schwarzkopf-Schauma-Szampon-do-wlosow-Power-Volume-48H-400-ml-27175_1-479014009.jpg', 6, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(39, 'Odżywka', ' Odżywka, przywracająca blask i miękkość włosom.', 34.99, '344295_392081_1280_720-1433794914.png', 6, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(40, 'Balsam do ciała', ' Przepyszny balsam do ciała o smaku kawy, intensywnie nawilżający skórę.', 49.99, 'gleb_odzywczy_balsam_cialo_kawa_spa-professional-2226635694.jpg', 6, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(41, 'Płyta muzyczna Kamerzysta Afirmacja', ' Płyta muzyczna, doskonała jako prezent psujący humor obdarowanego.', 39.99, '0c45a55b4ca3974454babe7e5f00-2934698842.jpg', 7, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(42, 'Bilet na koncert', ' Bilet na koncert, niezapomniane wrażenia muzyczne.', 99.99, 'bilety-sanah-90-1-3390394305.jpg', 7, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(43, 'Opony zimowe', ' Opony zimowe, zapewniające bezpieczeństwo na drodze.', 499.99, '4-Opony-zimowe-215-65R16-Debica-Frigo-HP-2-2397062051.jpg', 8, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(44, 'Olej silnikowy', ' Połówka oleju silnikowego. Tak, sprzedałem opla', 199.99, 'olej-silnikowy-mannol-extreme-5w-40-4-1l-syntetyczny_5408-38735107.png', 8, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(45, 'Waga łazienkowa', ' Waga łazienkowa, dokładna i funkcjonalna.', 199.99, 'waga-lazienkowa-clinica-ade-z-duzym-odczytem-i-powierzchnia-antyposlizgowa-ad-m-308800-2047049057.jpg', 9, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(46, 'Ciśnieniomierz', ' Ciśnieniomierz, monitorujący ciśnienie krwi.', 149.99, 'th-3211148379.jpg', 9, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(47, 'Glukometr', ' Miernik glukozy, ułatwiający kontrolę poziomu cukru.', 89.99, 'png-clipart-blood-glucose-meters-blood-glucose-monitoring-blood-sugar-ketone-bodies-blood-miscellaneous-service-4180515701.png', 9, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(48, 'Inhalator', ' Inhalator, pomocny przy problemach z oddychaniem.', 299.99, 'Inhalator-parowy-przenosny-dla-dzieci-i-doroslych-2602970812.jpg', 9, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(49, 'Opaska fitness', ' Opaska fitness, monitorująca aktywność fizyczną.', 199.99, 'md_wol7xbybnmQWwddsMZNvicV0NKKZfSDeufL6oD36-2016228283.jpeg', 1, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(50, 'Zestaw witamin', ' Zestaw witamin, wspierający zdrowie i energię.', 59.99, 'Centrum-ONA-50-zestaw-witamin-i-mineralow-dla-kobiet-30-tabl-431023100.jpg', 9, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(51, 'Mata do ćwiczeń', ' Mata do ćwiczeń, idealna do jogi i fitnessu.', 999.99, 'mata-do-jogi-i-cwiczen-fitme-antyposlizgowa-3575460102.jpg', 9, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(52, 'Torba podróżna', ' Torba podróżna, wytrzymała i pojemna.', 2349.99, 'pol_pl_Torba-podrozna-Leonardo-40922-Niebieska-4159_3-1217367925.jpg', 10, '2025-03-05 08:20:26', 0, 1, 'Aktywne'),
(53, 'Matiz', 'Sprzedam matiz, nic nie działa, ale nie bity :D', 7896.00, '1741291501_4337.gif', 8, '2025-03-06 19:04:40', 0, 3, 'Aktywne'),
(54, 'jabłecznik', 'dobry', 786.00, '1741638315_4983.jpg', 10, '2025-03-10 19:25:15', 0, 1, 'Aktywne'),
(55, 'Litwo! Ojczyzno moja! ty jesteś jak zdrowie.  Ile cię trzeba cenić, ten tylko się dowie,  Kto cię st', 'Litwo! Ojczyzno moja! ty jesteś jak zdrowie.\r\n\r\nIle cię trzeba cenić, ten tylko się dowie,\r\n\r\nKto cię stracił. Dziś piękność twą w całej ozdobie\r\n\r\nWidzę i opisuję, bo tęsknię po tobie.\r\n\r\n \r\n\r\nPanno Święta, co Jasnej bronisz Częstochowy\r\n\r\nI w Ostrej świecisz Bramie! Ty, co gród zamkowy\r\n\r\nNowogródzki ochraniasz z jego wiernym ludem!\r\n\r\nJak mnie dziecko do zdrowia powróciłaś cudem\r\n\r\n(Gdy od płaczącej matki pod Twoję opiekę\r\n\r\nOfiarowany, martwą podniosłem powiekę\r\n\r\nI zaraz mogłem pieszo do Twych świątyń progu\r\n\r\nIść za wrócone życie podziękować Bogu),\r\n\r\nTak nas powrócisz cudem na Ojczyzny łono.\r\n\r\nTymczasem przenoś moję duszę utęsknioną\r\n\r\nDo tych pagórków leśnych, do tych łąk zielonych,\r\n\r\nSzeroko nad błękitnym Niemnem rozciągnionych;\r\n\r\nDo tych pól malowanych zbożem rozmaitem,\r\n\r\nWyzłacanych pszenicą, posrebrzanych żytem;\r\n\r\nGdzie bursztynowy świerzop, gryka jak śnieg biała,\r\n\r\nGdzie panieńskim rumieńcem dzięcielina pała,\r\n\r\nA wszystko przepasane, jakby wstęgą, miedzą\r\n\r\nZieloną, na niej z rzadka ciche grusze siedzą.', 4343.00, 'default.webp', 10, '2025-03-11 13:14:41', 0, 3, 'Aktywne'),
(56, 'Renault Modus', 'Chciałem zaoszczędzić na zakupie używanego samochodu. Kupiłem go za 4k i wpakowałem w niego jakieś 10k a wciąż ma problemy z odpalaniem i co kilka dni muszę podłączać komputer żeby usunąć błędy. Był kupiony w sosnowcu w komisie jakimś. Chcę się go pozbyć i już nigdy nie widzieć. Te auto to takie badziewie, fotele były kiedyś jasne ale doszło do pewnego incydentu,', 10.00, '1741729320_4953.jpeg', 8, '2025-03-11 20:42:00', 1, 4, 'Aktywne'),
(57, 'Nóż do kupy', 'Sprzedam w miarę nowy nóż do kupy. Ja nie używałem dużo', 879.00, 'F31pzzeXoAIwLaT.png', 10, '2025-03-12 07:35:35', 0, 1, 'Aktywne'),
(58, 'Kot', 'h', 99999999.00, 'PXL_20250121_140353998.jpeg', 10, '2025-03-12 13:43:28', 0, 4, 'Aktywne'),
(63, 'Skoda Felicja', 'Sprzedam najgorszą felicje w powiecie. Potsufitka jest już czarna od szlugów, nie ma klimatyzacji, wsm niczego nie ma, a z nawiewu wylatują pająki i azbest', 1700.00, 'felicja.png', 8, '2025-03-26 07:41:29', 0, 1, 'Aktywne'),
(64, 'Gierki przeróżne', 'Sprzedam wiele Gierek', 288.00, 'gierki.png', 7, '2025-03-26 08:07:03', 0, 4, 'Aktywne'),
(65, 'Mercedes', 'W124 2.5D Igła 30 000PLN i zabieraj odrazu', 34000.00, 'mercedes.png', 8, '2025-03-26 08:15:12', 1, 12, 'Aktywne'),
(66, 'NAJLEPSZY KĄKUTER DLA GRACZA', '* Super Szybki Dysk SSD 120GB\r\n* Procesor Intel core I5 (2600)\r\n* Grafika Gefroce GTX (1060)\r\n* Pamięć RAM DDR3 800MHz\r\n* Zasilacz Bandit Power \r\n* Stylowa obudowa Akyga\r\n* Napęd DVD x16', 8600.00, 'SCR-20250326-iucq.jpeg', 1, '2025-03-26 08:26:48', 0, 12, 'Aktywne');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_admin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `first_name`, `last_name`, `created_at`, `is_admin`) VALUES
(1, 'admin', 'admin@alledrogo.pl', '$2y$10$R10jlGhYcNOLk/8bSYS3U.dsrIUWmFBUAE/tpr.eOvuqGVZ1YI/u6', 'Admin', '', '2025-02-11 15:45:06', 1),
(2, 'mydel', 'Alojzy@gmail.com', '$2y$10$oc09RAHUOkmDNt3/kG/Qqu6WsQn0Tl0tKr4NxLjHUOhiZqURJLieK', 'Mateusz', 'Klapek', '2025-03-04 13:15:39', 0),
(3, 'Mickiewicz98', 'jacek.rozycki@cok.vulcan.pl', '$2y$10$6oWg6KjPh/e0xcBBJGf1buwP7be50p/1P5UcWtf14ucg9VoYgW.ba', 'Jacek', 'Różycki', '2025-03-04 22:26:34', 0),
(4, 'rudy', 'rudy@rudy.pl', '$2y$10$esJhhniDsxWon610qKmVRuvMrwgOaDP2r6u9OTyIqySVMC0xsu.gi', 'Mikołaj', 'P', '2025-03-11 21:40:08', 0),
(12, 'pefes', 'andrzej.barwicki3@gmail.com', '$2y$10$xzJmIBD4Ze8ZOj3I9DI7fupyB48AvjzCjhGhwwPa7drQmQj33i1q6', 'Andrzej', 'Barwicki', '2025-03-26 08:12:52', 0);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indeksy dla tabeli `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `parent_message_id` (`parent_message_id`);

--
-- Indeksy dla tabeli `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `fk_seller_id` (`seller_id`);

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username_2` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `messages_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `messages_ibfk_4` FOREIGN KEY (`parent_message_id`) REFERENCES `messages` (`message_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_seller_id` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
