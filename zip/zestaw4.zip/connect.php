<?php
$conn = mysqli_connect(
    'localhost',
    'root', 
    '',
    'reprezentacja'
    );
?>





















































<!-- Jan Kupczyk -->