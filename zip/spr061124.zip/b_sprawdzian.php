<?php
if (isset($_POST['wybor'])) {

    $zadanie = $_POST['zadanie'];
    $a = $_POST['a'];
    $b = $_POST['b'];
    $color = $_POST['kolor'];
    $bold = "";
    $italic = "";
    $underline = "";
    if (isset($_POST['styl1'])) {
        $bold = 'font-weight: bold;';
    }
    if (isset($_POST['styl2'])) {
        $italic = 'font-style: italic;';
    }
    if (isset($_POST['styl3'])) {
        $underline = 'text-decoration: underline;';
    }
    $style = "<style>body { $bold $italic $underline color: $color; }</style>";
    echo $style;
    echo "Styl czcionki został zastosowany do całej strony.";


    switch ($zadanie) {
        case 'pierwsze':
            $sum = $a + $b;
            if ($sum == 0) {
                echo "Suma liczb jest równa 0";
            } elseif ($sum < 0) {
                echo "Suma liczb jest mniejsza od 0";
            } else {
                echo "Suma liczb jest większa od 0";
            }
            break;

        case 'drugie':
            if ($a > $b) {
                $c = $a;
                $a = $b;
                $b = $c;
            }
            $losowa1 = rand($a, $b);
            $losowa2 = rand($a, $b);

            echo "Wylosowane liczby to: $losowa1 i $losowa2.<br>";

            if ($losowa1 < 0) {
                echo "Liczba $losowa1 jest ujemna.<br>";
            }

            if ($losowa2 < 0) {
                echo "Liczba $losowa2 jest ujemna.<br>";
            }
            break;

        case 'trzecie':
            if ($a > $b) {
                $c = $a;
                $a = $b;
                $b = $c;
            }
            for ($i = $a; $i <= $b; $i++) {
                if ($i % 3 !== 0) {
                    echo $i;
                    if ($i < $b) {
                        for ($j = $i + 1; $j <= $b; $j++) {
                            if ($j % 3 !== 0) {
                                echo ", ";
                                break;
                            }
                        }
                    }
                }
            }
            break;
    }
    ;
}
?>