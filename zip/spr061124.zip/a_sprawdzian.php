<?php
if (isset($_POST['wybor'])) {

    $zadanie = $_POST['zadanie'];
    $x = $_POST['1'];
    $y = $_POST['2'];
    $bold = "";
    $italic = "";
    $underline = "";
    $color = $_POST['kolor'];

    if (isset($_POST['pogrubienie'])) {
        $bold = 'font-weight: bold;';
    }
    if (isset($_POST['pochylenie'])) {
        $italic = 'font-style: italic;';
    }
    if (isset($_POST['podkreslenie'])) {
        $underline = 'text-decoration: underline;';
    }

    $styl = "<style> body { $bold $italic $underline color: $color; }</style>";
    echo $styl;

    switch ($zadanie) {
        case 'zad1':
            if ($x == $y) {
                echo "Liczby są sobie równe";
            } elseif ($x > $y) {
                echo "Liczba_1 jest większa od Liczby_2";
            } else {
                echo "Liczba _1 jest mniejsza od Liczby _2";
            }
            break;

        case 'zad2':
            if ($x > $y) {
                $z = $x;
                $x = $y;
                $y = $z;
            }
            $random1 = rand($x, $y);
            $random2 = rand($x, $y);

            echo "Wylosowane liczby to: $random1 i $random2.<br>";

            if ($random1 < 0) {
                echo "Liczba $random1 jest ujemna.<br>";
            }

            if ($random2 < 0) {
                echo "Liczba $random2 jest ujemna.";
            }
            break;

        case 'zad3':
            if ($a > $b) {
                $c = $a;
                $a = $b;
                $b = $c;
            }
            for ($i = $a; $i <= $b; $i++) {
                if ($i % 3 == 0) {
                    echo $i;
                    if ($i < $b) {
                        for ($j = $i + 1; $j <= $b; $j++) {
                            if ($j % 3 == 0) {
                                echo ", ";
                                break;
                            }
                        }
                    }
                }
            }
            break;
    }
}