<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8">
</head>
<body>
	<h2>Sprawdzian GrA</h2>
	<form action="sprawdzian.php" method="post">
		Liczba 1 <input type="number" name="1" /><br/><br/>
		Liczba 2 <input type="number" name="2" /><br/><br/>
		Zaznacz styl czcionki:</br></br>
		<input type="checkbox" name="pogrubienie" />pogrubienie, 
		<input type="checkbox" name="pochylenie" />pochylenie, 
		<input type="checkbox" name="podkreslenie" />podkreślenie.<br /><br />
		Wybierz kolor czcionki:
		<select name="kolor">
				<option value="black">czarny</option>
				<option value="green">zielony</option>
				<option value="blue">niebieski</option>
				<option value="red">czerwony</option>
		</select><br/></br>
		Wybierz numer zadania:<br /><br />
		<input type="radio" checked name="zadanie" value="zad1" />Zadanie 1.
		<input type="radio" name="zadanie" value="zad2" />Zadanie 2.
		<input type="radio" name="zadanie" value="zad3" />Zadanie 3.<br/><br />
		<input type="submit" name="wybor" value="Wyświetl" />	
	</form>
</body>
</html>

<!-- Podpowiedź do zadania nr 4
<style type="text/css">
body
{
	color:white;
	font-weight:bold;
	font-style:italic;
	text-decoration:underline;
}
</style>
-->