// document.write("Siema Eniu!")
// var imie=prompt("Jak masz na imię?")
// document.write("Witaj ", imie)



// var liczba=parseInt(prompt("Podaj pierwszą liczbę"));
// var liczba2=parseInt(prompt("Podaj drugą liczbę"));
// document.write(liczba + liczba2);




// var kw=parseInt(prompt("Podaj bok kwadratu"));
// document.write("Obwód = ", 4 * kw, "<br>");
// document.write("Pole = ", kw * kw);


var wiek=parseInt(prompt("Jaki jesteś rocznik?"));
document.write("Masz ", 2023-wiek, " lat", "<br>");



// % reszta z dzielenia, dzielenie modulo