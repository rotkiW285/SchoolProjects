const IconSwitcher = () => {
    let o = 0;
    let x = 0;
    o++;

    if (o % 2 != 0) {
        document.getElementById("icon").src = "icon-on.png";

        console.log(o + x);
    } else {
        document.getElementById("icon").src = "icon-off.png";

        console.log(o + x);
    }
}

const ImageSwitcher = (argv) => {

    if (argv == "lanzarotte") {
        document.getElementById("StubAnnotation").src = "lanzarotte.jpg";
    } else
        if (argv == "pekin") {
            document.getElementById("StubAnnotation").src = "pekin.jpg";
        } else
            if (argv == "serengeti") {
                document.getElementById("StubAnnotation").src = "serengeti.jpg";
            } else
                if (argv == "tajlandia") {
                    document.getElementById("StubAnnotation").src = "tajlandia.jpg";
                } else
                    if (argv == "wenecja") {
                        document.getElementById("StubAnnotation").src = "wenecja.jpg";
                    }
}


IconSwitcher()
ImageSwitcher()

// Jan Kupczyk
