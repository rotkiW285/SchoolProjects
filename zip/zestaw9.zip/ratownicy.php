<!DOCTYPE html>
<html lang="pl-PL">

<head>
	<meta charset="UTF-8" />
	<title>Zespoły ratownicze</title>
	<link rel="stylesheet" href="styl3.css" />
</head>

<body>
	<div class="baner1">
		<h2>Dodanie zespołu ratowniczego</h2>
	</div>
	<div class="baner2">
		<p>Kontakt: 022 222 11 333</p><br>
	</div>
	<div class="baner3">
		<img src="obraz.jpg" alt="Ratownicy" />
	</div>
	<div class="main">
		<h3>Dodaj nowy zespół</h3>
		<form action="ratownicy.php" method="POST">
			<label>Numer karetki: <input type="number" name="karetka" /></label><br>
			<label>Imię i nazwisko pierwszego ratownika: <input type="text" name="r1" /></label><br>
			<label>Imię i nazwisko drugiego ratownika: <input type="text" name="r2" /></label><br>
			<label>Imię i nazwisko trzeciego ratownika: <input type="text" name="r3" /></label><br><br>
			<input type="reset" value="CZYŚĆ" />
			<input type="submit" value="DODAJ" name="btn" />
			<?php

			$conn = mysqli_connect('localhost', 'root', '', 'baza3');
			$resp = "<br>Do bazy zostało wysłane zapytanie";

			if (isset($_POST['btn'])) {
				$kar = $_POST['karetka'];
				$r1 = $_POST['r1'];
				$r2 = $_POST['r2'];
				$r3 = $_POST['r3'];

				$qrr = "INSERT INTO ratownicy (nrKaretki, ratownik1, ratownik2, ratownik3) VALUES ('$kar', '$r1', '$r2', '$r3');";

				echo "$resp: $qrr";
			}
			mysqli_close($conn);

			?>

		</form>

	</div>
	<div class="stopka1">
		<a href="kwerendy.txt" download>Zobacz kwerendy</a>
	</div>
	<div class="stopka2">
		<h5>Przypominamy numery alarmowe</h5>
		<ol>
			<li>112</li>
			<li>999</li>
		</ol>
	</div>
	<div class="stopka3">
		<p>Autor: Jan Kupczyk</p>
	</div>
</body>

</html>



<!-- Jan Kupczyk -->